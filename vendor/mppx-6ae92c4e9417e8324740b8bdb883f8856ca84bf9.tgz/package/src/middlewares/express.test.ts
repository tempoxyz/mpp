import express from 'express'
import { Receipt } from 'mppx'
import {
  Mppx as Mppx_client,
  sessionLegacy as sessionIntent,
  tempo as tempo_client,
} from 'mppx/client'
import { Mppx, discovery, payment } from 'mppx/express'
import { Mppx as Mppx_server, tempo as tempo_server } from 'mppx/server'
import type { Address } from 'viem'
import { Addresses } from 'viem/tempo'
import { beforeAll, describe, expect, test } from 'vp/test'
import * as Http from '~test/Http.js'
import { deployEscrow } from '~test/tempo/legacy/session.js'
import { accounts, asset, client, fundAccount } from '~test/tempo/viem.js'

function createServer(app: express.Express) {
  return new Promise<Http.TestServer>((resolve) => {
    const server = app.listen(0, () => {
      const { port } = server.address() as { port: number }
      resolve(Http.wrapServer(server, { port, url: `http://localhost:${port}` }))
    })
  })
}

const secretKey = 'test-secret-key'

function createChargeHarness(feePayer: boolean) {
  const mppx = Mppx.create({
    methods: [
      tempo_server({
        getClient: () => client,
        currency: asset,
        account: accounts[0],
        ...(feePayer ? { feePayer: true } : {}),
      }),
    ],
    secretKey,
  })

  const { fetch } = Mppx_client.create({
    polyfill: false,
    methods: [
      tempo_client({
        account: accounts[1],
        getClient: () => client,
      }),
    ],
  })

  return { fetch, mppx }
}

function createCoreChargeHarness(feePayer: boolean) {
  const mppx = Mppx_server.create({
    methods: [
      tempo_server({
        getClient: () => client,
        currency: asset,
        account: accounts[0],
        ...(feePayer ? { feePayer: true } : {}),
      }),
    ],
    secretKey,
  })

  const { fetch } = Mppx_client.create({
    polyfill: false,
    methods: [
      tempo_client({
        account: accounts[1],
        getClient: () => client,
      }),
    ],
  })

  return { fetch, mppx }
}

describe('charge', () => {
  test('returns 402 when no credential', async () => {
    const { mppx } = createChargeHarness(false)

    const app = express()
    app.get('/', mppx.charge({ amount: '1' }), (_req, res) => {
      res.json({ fortune: 'You will be rich' })
    })

    const server = await createServer(app)
    const response = await globalThis.fetch(server.url)
    expect(response.status).toBe(402)
    expect(response.headers.get('WWW-Authenticate')).toContain('Payment')

    server.close()
  })

  test('returns 200 with receipt on valid payment', async () => {
    const { fetch, mppx } = createChargeHarness(false)

    const app = express()
    app.get('/', mppx.charge({ amount: '1' }), (_req, res) => {
      res.json({ fortune: 'You will be rich' })
    })

    const server = await createServer(app)
    const response = await fetch(server.url)
    expect(response.status).toBe(200)

    const body = await response.json()
    expect(body).toEqual({ fortune: 'You will be rich' })

    const receiptHeader = response.headers.get('Payment-Receipt')
    expect(receiptHeader).toBeTruthy()

    const receipt = Receipt.fromResponse(response)
    expect(receipt.status).toBe('success')
    expect(receipt.method).toBe('tempo')

    server.close()
  })

  test('fee payer: returns 200 with receipt on valid payment', async () => {
    const { fetch, mppx } = createChargeHarness(true)

    const app = express()
    app.get('/', mppx.charge({ amount: '1' }), (_req, res) => {
      res.json({ fortune: 'You will be rich' })
    })

    const server = await createServer(app)
    const response = await fetch(server.url)
    expect(response.status).toBe(200)
    expect(Receipt.fromResponse(response).status).toBe('success')

    server.close()
  })

  test('serves /openapi.json from a handler-derived route config', async () => {
    const { mppx } = createChargeHarness(false)

    const app = express()
    const pay = mppx.charge({ amount: '1' })
    app.get('/', pay, (_req, res) => {
      res.json({ fortune: 'You will be rich' })
    })
    discovery(app, mppx, {
      info: { title: 'Express API', version: '1.2.3' },
      routes: [{ handler: pay, method: 'get', path: '/' }],
    })

    const server = await createServer(app)
    const response = await globalThis.fetch(`${server.url}/openapi.json`)
    expect(response.status).toBe(200)
    expect(response.headers.get('cache-control')).toBe('public, max-age=300')

    const body = (await response.json()) as Record<string, any>
    expect(body.info).toEqual({ title: 'Express API', version: '1.2.3' })
    expect(body.paths['/'].get['x-payment-info'].offers[0]).toMatchObject({
      amount: '1000000',
      currency: asset,
      intent: 'charge',
      method: 'tempo',
    })

    server.close()
  })
})

describe('payment', () => {
  test('copies transport-specific success headers', async () => {
    const intent = () => async () => ({
      status: 200 as const,
      withReceipt: (response?: Response) =>
        new Response(response?.body ?? null, {
          headers: {
            ...(response ? Object.fromEntries(response.headers) : {}),
            'PAYMENT-RESPONSE': 'x402-response',
          },
          status: response?.status ?? 200,
        }),
    })

    const app = express()
    app.get('/', payment(intent as any, {} as any), (_req, res) => {
      res.json({ data: 'content' })
    })

    const server = await createServer(app)
    const response = await globalThis.fetch(server.url)
    expect(response.status).toBe(200)
    expect(response.headers.get('PAYMENT-RESPONSE')).toBe('x402-response')

    server.close()
  })
})

describe('session', () => {
  let escrowContract: Address

  function createSessionHarness(feePayer: boolean) {
    const mppx = Mppx.create({
      methods: [
        tempo_server.sessionLegacy({
          getClient: () => client,
          account: accounts[0],
          currency: asset,
          escrowContract,
          ...(feePayer ? { feePayer: accounts[1] } : {}),
        } as any),
      ],
      secretKey,
    })

    const { fetch } = Mppx_client.create({
      polyfill: false,
      methods: [
        sessionIntent({
          account: accounts[2],
          maxDeposit: '10',
          getClient: () => client,
        }),
      ],
    })

    return { fetch, mppx }
  }

  beforeAll(async () => {
    escrowContract = await deployEscrow()
    await fundAccount({ address: accounts[1].address, token: Addresses.pathUsd })
    await fundAccount({ address: accounts[1].address, token: asset })
    await fundAccount({ address: accounts[2].address, token: Addresses.pathUsd })
    await fundAccount({ address: accounts[2].address, token: asset })
  })

  test('returns 402 when no credential', async () => {
    const { mppx } = createSessionHarness(false)

    const app = express()
    app.get('/', mppx.session({ amount: '1', currency: asset, unitType: 'token' }), (_req, res) => {
      res.json({ data: 'streamed' })
    })

    const server = await createServer(app)
    const response = await globalThis.fetch(server.url)
    expect(response.status).toBe(402)
    expect(response.headers.get('WWW-Authenticate')).toContain('Payment')

    server.close()
  })

  test('returns 200 with receipt on valid payment', async () => {
    const { fetch, mppx } = createSessionHarness(false)

    const app = express()
    app.get('/', mppx.session({ amount: '1', currency: asset, unitType: 'token' }), (_req, res) => {
      res.json({ data: 'streamed' })
    })

    const server = await createServer(app)
    const response = await fetch(server.url)
    expect(response.status).toBe(200)

    const body = await response.json()
    expect(body).toEqual({ data: 'streamed' })

    server.close()
  })

  test('fee payer: returns 200 with receipt on valid payment', async () => {
    const { fetch, mppx } = createSessionHarness(true)

    const app = express()
    app.get('/', mppx.session({ amount: '1', currency: asset, unitType: 'token' }), (_req, res) => {
      res.json({ data: 'streamed' })
    })

    const server = await createServer(app)
    const response = await fetch(server.url)
    expect(response.status).toBe(200)
    expect(Receipt.fromResponse(response).status).toBe('success')

    server.close()
  })
})

describe('payment', () => {
  test('short-circuits management responses', async () => {
    let handlerRan = false
    const managementResponse = new Response(null, {
      status: 204,
      headers: { 'Payment-Receipt': 'management-receipt' },
    })
    const intent = () => async () => ({
      status: 200 as const,
      withReceipt: () => managementResponse,
    })

    const app = express()
    app.get('/', payment(intent as any, {} as any), (_req, res) => {
      handlerRan = true
      res.json({ data: 'content' })
    })

    const server = await createServer(app)
    const response = await globalThis.fetch(server.url)
    expect(response.status).toBe(204)
    expect(response.headers.get('Payment-Receipt')).toBe('management-receipt')
    expect(await response.text()).toBe('')
    expect(handlerRan).toBe(false)

    server.close()
  })

  test('returns 402 when no credential', async () => {
    const { mppx } = createCoreChargeHarness(false)

    const app = express()
    app.get('/', payment(mppx.charge, { amount: '1' }), (_req, res) => {
      res.json({ fortune: 'You will be rich' })
    })

    const server = await createServer(app)
    const response = await globalThis.fetch(server.url)
    expect(response.status).toBe(402)
    expect(response.headers.get('WWW-Authenticate')).toContain('Payment')

    server.close()
  })

  test('returns 200 with receipt on valid payment', async () => {
    const { fetch, mppx } = createCoreChargeHarness(false)

    const app = express()
    app.get('/', payment(mppx.charge, { amount: '1' }), (_req, res) => {
      res.json({ fortune: 'You will be rich' })
    })

    const server = await createServer(app)
    const response = await fetch(server.url)
    expect(response.status).toBe(200)

    const body = await response.json()
    expect(body).toEqual({ fortune: 'You will be rich' })

    const receiptHeader = response.headers.get('Payment-Receipt')
    expect(receiptHeader).toBeTruthy()

    const receipt = Receipt.fromResponse(response)
    expect(receipt.status).toBe('success')
    expect(receipt.method).toBe('tempo')

    server.close()
  })

  test('fee payer: returns 200 with receipt on valid payment', async () => {
    const { fetch, mppx } = createCoreChargeHarness(true)

    const app = express()
    app.get('/', payment(mppx.charge, { amount: '1' }), (_req, res) => {
      res.json({ fortune: 'You will be rich' })
    })

    const server = await createServer(app)
    const response = await fetch(server.url)
    expect(response.status).toBe(200)
    expect(Receipt.fromResponse(response).status).toBe('success')

    server.close()
  })
})

import { Challenge, Credential, Errors, Mcp, Method, Receipt } from 'mppx'
import { Mppx, Transport, tempo } from 'mppx/client'
import { Mppx as Mppx_server, tempo as tempo_server } from 'mppx/server'
import { Methods } from 'mppx/tempo'
import { afterEach, describe, expect, test, vi } from 'vp/test'
import * as Http from '~test/Http.js'
import { accounts, asset, client } from '~test/tempo/viem.js'

const realm = 'api.example.com'
const secretKey = 'test-secret-key'

afterEach(() => {
  Mppx.restore()
})

describe('Mppx.create', () => {
  test('default', () => {
    const mppx = Mppx.create({
      polyfill: false,
      methods: [tempo({ account: accounts[1], getClient: () => client })],
    })

    expect(mppx.methods).toHaveLength(2)
    expect(mppx.methods[0]?.name).toBe('tempo')
    expect(mppx.methods[0]?.intent).toBe('charge')
    expect(mppx.methods[1]?.name).toBe('tempo')
    expect(mppx.methods[1]?.intent).toBe('session')
    expect(mppx.transport.name).toBe('http')
    expect(typeof mppx.createCredential).toBe('function')
    expect(typeof mppx.fetch).toBe('function')
    expect(typeof mppx.rawFetch).toBe('function')
  })

  test('behavior: with mcp transport', () => {
    const mppx = Mppx.create({
      polyfill: false,
      methods: [tempo({ account: accounts[1], getClient: () => client })],
      transport: Transport.mcp(),
    })

    expect(mppx.transport.name).toBe('mcp')
  })

  test('behavior: with multiple methods', () => {
    const stripeCharge = Method.from({
      name: 'stripe',
      intent: 'charge',
      schema: {
        credential: {
          payload: Methods.charge.schema.credential.payload,
        },
        request: Methods.charge.schema.request,
      },
    })
    const stripeMethod = Method.toClient(stripeCharge, {
      async createCredential({ challenge }) {
        return Credential.serialize({
          challenge,
          payload: { signature: '0xstripe', type: 'transaction' },
        })
      },
    })

    const mppx = Mppx.create({
      polyfill: false,
      methods: [tempo({ account: accounts[1], getClient: () => client }), stripeMethod],
    })

    expect(mppx.methods).toHaveLength(3)
    expect(mppx.methods[0]?.name).toBe('tempo')
    expect(mppx.methods[1]?.name).toBe('tempo')
    expect(mppx.methods[2]?.name).toBe('stripe')
  })
})

describe('createCredential', () => {
  function sessionChallenge(id: string, sessionProtocol?: string) {
    return {
      expires: new Date(Date.now() + 60_000).toISOString(),
      id,
      intent: 'session',
      method: 'tempo',
      realm,
      request: {
        amount: '100',
        currency: asset,
        unitType: 'request',
        methodDetails: {
          chainId: 1,
          escrowContract: '0x0000000000000000000000000000000000000001',
          ...(sessionProtocol !== undefined ? { sessionProtocol } : {}),
        },
      },
    } as const
  }

  function paymentRequiredResponse(...challenges: Challenge.Challenge[]) {
    return new Response(null, {
      status: 402,
      headers: { 'WWW-Authenticate': challenges.map(Challenge.serialize).join(', ') },
    })
  }

  function taggedSessionMethod(tag: string, canHandleChallenge: Method.CanHandleChallengeFn) {
    return Method.toClient(Methods.session, {
      canHandleChallenge,
      async createCredential({ challenge }) {
        return Credential.serialize({ challenge, payload: { tag } })
      },
    })
  }

  test('behavior: routes duplicate tempo/session client methods by sessionProtocol', async () => {
    const tip1034 = taggedSessionMethod(
      'v2',
      ({ challenge }) =>
        (challenge.request.methodDetails as { sessionProtocol?: string } | undefined)
          ?.sessionProtocol === 'v2',
    )
    const legacy = taggedSessionMethod('v1', ({ challenge }) => {
      const sessionProtocol = (
        challenge.request.methodDetails as { sessionProtocol?: string } | undefined
      )?.sessionProtocol
      return sessionProtocol === undefined || sessionProtocol === 'v1'
    })
    const mppx = Mppx.create({ polyfill: false, methods: [tip1034, legacy] })

    const [newCredential, legacyCredential, oldCredential] = await Promise.all([
      mppx.createCredential(paymentRequiredResponse(sessionChallenge('new', 'v2'))),
      mppx.createCredential(paymentRequiredResponse(sessionChallenge('v1', 'v1'))),
      mppx.createCredential(paymentRequiredResponse(sessionChallenge('old'))),
    ])
    expect(Credential.deserialize(newCredential).payload).toEqual({ tag: 'v2' })
    expect(Credential.deserialize(legacyCredential).payload).toEqual({ tag: 'v1' })
    expect(Credential.deserialize(oldCredential).payload).toEqual({ tag: 'v1' })
  })

  test('behavior: rejects unknown tempo/session sessionProtocol', async () => {
    const method = taggedSessionMethod(
      'v2',
      ({ challenge }) =>
        (challenge.request.methodDetails as { sessionProtocol?: string } | undefined)
          ?.sessionProtocol === 'v2',
    )
    const mppx = Mppx.create({ polyfill: false, methods: [method] })

    await expect(
      mppx.createCredential(paymentRequiredResponse(sessionChallenge('unknown', 'future'))),
    ).rejects.toThrow('No method found for challenges: tempo.session')
  })

  test('behavior: routes to correct method based on challenge', async () => {
    const mppx = Mppx.create({
      polyfill: false,
      methods: [tempo({ account: accounts[1], getClient: () => client })],
    })

    const challenge = Challenge.fromMethod(Methods.charge, {
      realm,
      secretKey,
      expires: new Date(Date.now() + 60_000).toISOString(),
      request: {
        amount: '1000',
        currency: '0x1234567890123456789012345678901234567890',
        decimals: 6,
        recipient: '0x1234567890123456789012345678901234567890',
      },
    })

    const response = new Response(null, {
      status: 402,
      headers: {
        'WWW-Authenticate': Challenge.serialize(challenge),
      },
    })

    const credential = await mppx.createCredential(response)

    expect(credential).toMatch(/^Payment /)

    const parsed = Credential.deserialize(credential)
    expect((parsed.payload as { type: string }).type).toBe('transaction')
    expect(parsed.challenge.method).toBe('tempo')
  })

  test('behavior: createCredential emits client events and supports runtime handlers', async () => {
    const events: string[] = []
    const createCredential = vi.fn(async ({ challenge }) =>
      Credential.serialize({
        challenge,
        payload: { signature: '0xsignature', type: 'transaction' },
      }),
    )
    const method = Method.toClient(Methods.charge, { createCredential })
    const mppx = Mppx.create({
      polyfill: false,
      methods: [method],
    })
    mppx.onCredentialCreated((payload) => {
      events.push(`credential:${payload.credential.startsWith('Payment ')}`)
    })
    const offCredential = mppx.onCredentialCreated(() => {
      events.push('removed')
    })
    const offChallenge = mppx.onChallengeReceived((payload) => {
      events.push(`runtime:${payload.method.intent}`)
      return payload.createCredential()
    })
    mppx.on('*', (event) => {
      events.push(`*:${event.name}`)
    })
    offCredential()

    const challenge = Challenge.fromMethod(Methods.charge, {
      realm,
      secretKey,
      expires: new Date(Date.now() + 60_000).toISOString(),
      request: {
        amount: '1000',
        currency: '0x1234567890123456789012345678901234567890',
        decimals: 6,
        recipient: '0x1234567890123456789012345678901234567890',
      },
    })
    const response = new Response(null, {
      status: 402,
      headers: {
        'WWW-Authenticate': Challenge.serialize(challenge),
      },
    })

    const credential = await mppx.createCredential(response)
    offChallenge()

    expect(credential).toMatch(/^Payment /)
    expect(createCredential).toHaveBeenCalledTimes(1)
    expect(events).toEqual([
      'runtime:charge',
      '*:challenge.received',
      'credential:true',
      '*:credential.created',
    ])
  })

  test('behavior: createCredential memoizes event helper calls', async () => {
    const createCredential = vi.fn(async ({ challenge }) =>
      Credential.serialize({
        challenge,
        payload: { signature: '0xsignature', type: 'transaction' },
      }),
    )
    const method = Method.toClient(Methods.charge, { createCredential })
    const mppx = Mppx.create({
      polyfill: false,
      methods: [method],
    })
    mppx.on('*', async (event) => {
      if (event.name === 'challenge.received') await event.payload.createCredential()
    })

    const challenge = Challenge.fromMethod(Methods.charge, {
      realm,
      secretKey,
      expires: new Date(Date.now() + 60_000).toISOString(),
      request: {
        amount: '1000',
        currency: '0x1234567890123456789012345678901234567890',
        decimals: 6,
        recipient: '0x1234567890123456789012345678901234567890',
      },
    })
    const response = new Response(null, {
      status: 402,
      headers: {
        'WWW-Authenticate': Challenge.serialize(challenge),
      },
    })

    await mppx.createCredential(response)

    expect(createCredential).toHaveBeenCalledTimes(1)
  })

  test('behavior: createCredential validates event credentials', async () => {
    const mppx = Mppx.create({
      polyfill: false,
      methods: [tempo({ account: accounts[1], getClient: () => client })],
    })
    mppx.onChallengeReceived(() => 'Payment invalid\r\nX-Injected: true')

    const challenge = Challenge.fromMethod(Methods.charge, {
      realm,
      secretKey,
      expires: new Date(Date.now() + 60_000).toISOString(),
      request: {
        amount: '1000',
        currency: '0x1234567890123456789012345678901234567890',
        decimals: 6,
        recipient: '0x1234567890123456789012345678901234567890',
      },
    })
    const response = new Response(null, {
      status: 402,
      headers: {
        'WWW-Authenticate': Challenge.serialize(challenge),
      },
    })

    await expect(mppx.createCredential(response)).rejects.toThrow('illegal newline')
  })

  test('behavior: throws when method not found', async () => {
    const events: string[] = []
    const mppx = Mppx.create({
      polyfill: false,
      methods: [tempo({ account: accounts[1], getClient: () => client })],
    })
    mppx.onPaymentFailed((payload) => {
      events.push(
        `failed:${payload.challenge === undefined}:${payload.challenges?.length}:${payload.error instanceof Error}`,
      )
    })

    const challenge = Challenge.from({
      id: 'test-id',
      realm,
      method: 'unknown',
      intent: 'charge',
      request: { amount: '1000', currency: '0x1234' },
    })

    const response = new Response(null, {
      status: 402,
      headers: {
        'WWW-Authenticate': Challenge.serialize(challenge),
      },
    })

    await expect(mppx.createCredential(response)).rejects.toThrow(
      'No method found for challenges: unknown.charge. Available: tempo.charge, tempo.session',
    )
    expect(events).toEqual(['failed:true:1:true'])
  })

  test('behavior: rejects expired challenges before creating credential', async () => {
    const createCredential = vi.fn(async ({ challenge }) =>
      Credential.serialize({
        challenge,
        payload: { signature: '0xsignature', type: 'transaction' },
      }),
    )
    const method = Method.toClient(Methods.charge, { createCredential })
    const mppx = Mppx.create({
      polyfill: false,
      methods: [method],
    })

    const challenge = Challenge.fromMethod(Methods.charge, {
      realm,
      secretKey,
      expires: new Date(Date.now() - 60_000).toISOString(),
      request: {
        amount: '1000',
        currency: '0x1234567890123456789012345678901234567890',
        decimals: 6,
        recipient: '0x1234567890123456789012345678901234567890',
      },
    })

    const response = new Response(null, {
      status: 402,
      headers: {
        'WWW-Authenticate': Challenge.serialize(challenge),
      },
    })

    await expect(mppx.createCredential(response)).rejects.toThrow(Errors.PaymentExpiredError)
    expect(createCredential).not.toHaveBeenCalled()
  })

  test('behavior: routes to correct method with multiple methods', async () => {
    const stripeCharge = Method.from({
      name: 'stripe',
      intent: 'charge',
      schema: {
        credential: {
          payload: Methods.charge.schema.credential.payload,
        },
        request: Methods.charge.schema.request,
      },
    })

    const stripe = Method.toClient(stripeCharge, {
      async createCredential({ challenge }) {
        return Credential.serialize({
          challenge,
          payload: { signature: '0xstripe', type: 'transaction' },
        })
      },
    })

    const mppx = Mppx.create({
      polyfill: false,
      methods: [tempo({ account: accounts[1], getClient: () => client }), stripe],
    })

    const stripeChallenge = Challenge.from({
      id: 'stripe-challenge-id',
      realm,
      method: 'stripe',
      intent: 'charge',
      request: {
        amount: '2000',
        currency: '0xabcd',
        recipient: '0xefgh',
      },
    })

    const response = new Response(null, {
      status: 402,
      headers: {
        'WWW-Authenticate': Challenge.serialize(stripeChallenge),
      },
    })

    const credential = await mppx.createCredential(response)
    const parsed = Credential.deserialize(credential)

    expect(parsed.payload).toEqual({ signature: '0xstripe', type: 'transaction' })
    expect(parsed.challenge.method).toBe('stripe')
  })

  test('behavior: selects the preferred challenge from a multi-challenge response', async () => {
    const stripeCharge = Method.from({
      name: 'stripe',
      intent: 'charge',
      schema: {
        credential: {
          payload: Methods.charge.schema.credential.payload,
        },
        request: Methods.charge.schema.request,
      },
    })

    const stripe = Method.toClient(stripeCharge, {
      async createCredential({ challenge }) {
        return Credential.serialize({
          challenge,
          payload: { signature: '0xstripe', type: 'transaction' },
        })
      },
    })

    const mppx = Mppx.create({
      polyfill: false,
      methods: [tempo({ account: accounts[1], getClient: () => client }), stripe],
      paymentPreferences: ({ stripe }) => ({
        [stripe.charge]: 0.5,
      }),
    })

    const tempoChallenge = Challenge.fromMethod(Methods.charge, {
      realm,
      secretKey,
      expires: new Date(Date.now() + 60_000).toISOString(),
      request: {
        amount: '1000',
        currency: '0x1234567890123456789012345678901234567890',
        decimals: 6,
        recipient: '0x1234567890123456789012345678901234567890',
      },
    })
    const stripeChallenge = Challenge.from({
      id: 'stripe-challenge-id',
      realm,
      method: 'stripe',
      intent: 'charge',
      request: {
        amount: '2000',
        currency: '0xabcd',
        recipient: '0xefgh',
      },
    })

    const response = new Response(null, {
      status: 402,
      headers: {
        'WWW-Authenticate': `${Challenge.serialize(stripeChallenge)}, ${Challenge.serialize(tempoChallenge)}`,
      },
    })

    const credential = await mppx.createCredential(response)
    const parsed = Credential.deserialize(credential)

    expect(parsed.challenge.method).toBe('tempo')
  })

  test('behavior: createCredential accepts a request-local Accept-Payment override', async () => {
    const stripeCharge = Method.from({
      name: 'stripe',
      intent: 'charge',
      schema: {
        credential: {
          payload: Methods.charge.schema.credential.payload,
        },
        request: Methods.charge.schema.request,
      },
    })

    const stripe = Method.toClient(stripeCharge, {
      async createCredential({ challenge }) {
        return Credential.serialize({
          challenge,
          payload: { signature: '0xstripe', type: 'transaction' },
        })
      },
    })

    const mppx = Mppx.create({
      polyfill: false,
      methods: [tempo({ account: accounts[1], getClient: () => client }), stripe],
    })

    const tempoChallenge = Challenge.fromMethod(Methods.charge, {
      realm,
      secretKey,
      expires: new Date(Date.now() + 60_000).toISOString(),
      request: {
        amount: '1000',
        currency: '0x1234567890123456789012345678901234567890',
        decimals: 6,
        recipient: '0x1234567890123456789012345678901234567890',
      },
    })
    const stripeChallenge = Challenge.from({
      id: 'stripe-challenge-id',
      realm,
      method: 'stripe',
      intent: 'charge',
      expires: new Date(Date.now() + 60_000).toISOString(),
      request: {
        amount: '2000',
        currency: '0xabcd',
        recipient: '0xefgh',
      },
    })

    const response = new Response(null, {
      status: 402,
      headers: {
        'WWW-Authenticate': `${Challenge.serialize(stripeChallenge)}, ${Challenge.serialize(tempoChallenge)}`,
      },
    })

    const credential = await mppx.createCredential(response, undefined, {
      acceptPayment: 'stripe/charge, tempo/charge;q=0.1',
    })
    const parsed = Credential.deserialize(credential)

    expect(parsed.challenge.method).toBe('stripe')
  })

  test('behavior: createCredential accepts request-local challenge ordering', async () => {
    const testMethod = Method.toClient(
      Method.from({
        name: 'test',
        intent: 'test',
        schema: Methods.charge.schema,
      }),
      {
        async createCredential({ challenge }) {
          return Credential.serialize({
            challenge,
            payload: { signature: `0x${challenge.id}`, type: 'transaction' },
          })
        },
      },
    )

    const mppx = Mppx.create({
      polyfill: false,
      methods: [testMethod],
    })

    const first = Challenge.from({
      id: '1111',
      realm,
      method: 'test',
      intent: 'test',
      request: { currency: 'pathusd' },
    })
    const second = Challenge.from({
      id: '2222',
      realm,
      method: 'test',
      intent: 'test',
      request: { currency: 'usdc' },
    })
    const response = new Response(null, {
      status: 402,
      headers: {
        'WWW-Authenticate': `${Challenge.serialize(first)}, ${Challenge.serialize(second)}`,
      },
    })

    const credential = await mppx.createCredential(response, undefined, {
      orderChallenges: (candidates) =>
        candidates.filter(({ challenge }) => challenge.request.currency === 'usdc'),
    })
    const parsed = Credential.deserialize(credential)

    expect(parsed.challenge.id).toBe('2222')
  })

  test('behavior: passes context to createCredential', async () => {
    const mppx = Mppx.create({
      polyfill: false,
      methods: [tempo({ getClient: () => client })],
    })

    const challenge = Challenge.fromMethod(Methods.charge, {
      realm,
      secretKey,
      expires: new Date(Date.now() + 60_000).toISOString(),
      request: {
        amount: '1000',
        currency: '0x1234567890123456789012345678901234567890',
        decimals: 6,
        recipient: '0x1234567890123456789012345678901234567890',
      },
    })

    const response = new Response(null, {
      status: 402,
      headers: {
        'WWW-Authenticate': Challenge.serialize(challenge),
      },
    })

    const credential = await mppx.createCredential(response, { account: accounts[1] })

    const parsed = Credential.deserialize(credential)
    expect((parsed.payload as { type: string }).type).toBe('transaction')
    expect(parsed.source).toContain(accounts[1].address)
  })

  test('behavior: works without context when account provided at creation', async () => {
    const mppx = Mppx.create({
      polyfill: false,
      methods: [tempo({ account: accounts[1], getClient: () => client })],
    })

    const challenge = Challenge.fromMethod(Methods.charge, {
      realm,
      secretKey,
      expires: new Date(Date.now() + 60_000).toISOString(),
      request: {
        amount: '1000',
        currency: '0x1234567890123456789012345678901234567890',
        decimals: 6,
        recipient: '0x1234567890123456789012345678901234567890',
      },
    })

    const response = new Response(null, {
      status: 402,
      headers: {
        'WWW-Authenticate': Challenge.serialize(challenge),
      },
    })

    const credential = await mppx.createCredential(response)
    const parsed = Credential.deserialize(credential)
    expect((parsed.payload as { type: string }).type).toBe('transaction')
  })

  test('behavior: with mcp transport', async () => {
    const mppx = Mppx.create({
      polyfill: false,
      methods: [tempo({ account: accounts[1], getClient: () => client })],
      transport: Transport.mcp(),
    })

    const challenge = Challenge.fromMethod(Methods.charge, {
      realm,
      secretKey,
      expires: new Date(Date.now() + 60_000).toISOString(),
      request: {
        amount: '1000',
        currency: '0x1234567890123456789012345678901234567890',
        decimals: 6,
        recipient: '0x1234567890123456789012345678901234567890',
      },
    })

    const mcpResponse: Mcp.Response = {
      jsonrpc: '2.0',
      id: 1,
      error: {
        code: Mcp.paymentRequiredCode,
        message: 'Payment Required',
        data: {
          httpStatus: 402,
          challenges: [challenge],
        },
      },
    }

    const credential = await mppx.createCredential(mcpResponse)
    const parsed = Credential.deserialize(credential)
    expect((parsed.payload as { type: string }).type).toBe('transaction')
    expect(parsed.challenge.method).toBe('tempo')
  })

  test('behavior: mcp transport event responses are not cast to DOM Response', async () => {
    const method = Method.toClient(Methods.charge, {
      async createCredential({ challenge }) {
        return Credential.serialize({
          challenge,
          payload: { signature: '0xsignature', type: 'transaction' },
        })
      },
    })
    const mppx = Mppx.create({
      polyfill: false,
      methods: [method],
      transport: Transport.mcp(),
    })

    const challenge = Challenge.fromMethod(Methods.charge, {
      realm,
      secretKey,
      expires: new Date(Date.now() + 60_000).toISOString(),
      request: {
        amount: '1000',
        currency: '0x1234567890123456789012345678901234567890',
        decimals: 6,
        recipient: '0x1234567890123456789012345678901234567890',
      },
    })
    const mcpResponse: Mcp.Response = {
      jsonrpc: '2.0',
      id: 1,
      error: {
        code: Mcp.paymentRequiredCode,
        message: 'Payment Required',
        data: {
          httpStatus: 402,
          challenges: [challenge],
        },
      },
    }
    const seen: unknown[] = []
    mppx.onChallengeReceived((event) => {
      seen.push(event.response)
    })

    await mppx.createCredential(mcpResponse)

    expect(seen).toEqual([mcpResponse])
  })
})

const server = Mppx_server.create({
  methods: [
    tempo_server.charge({
      currency: asset,
      getClient: () => client,
      recipient: accounts[0].address,
    }),
  ],
  secretKey,
})

describe('fetch', () => {
  test('default: handles 402 automatically', async () => {
    const mppx = Mppx.create({
      polyfill: false,
      methods: [
        tempo({
          account: accounts[1],
          getClient: () => client,
        }),
      ],
    })

    const httpServer = await Http.createServer(async (req, res) => {
      const result = await Mppx_server.toNodeListener(
        server.charge({
          amount: '1',
        }),
      )(req, res)
      if (result.status === 402) return
      res.end('OK')
    })

    const response = await mppx.fetch(httpServer.url)
    expect(response.status).toBe(200)

    const receipt = Receipt.fromResponse(response)
    expect(receipt.status).toBe('success')
    expect(receipt.method).toBe('tempo')

    httpServer.close()
  })

  test('behavior: passes through non-402 responses', async () => {
    const mppx = Mppx.create({
      polyfill: false,
      methods: [
        tempo({
          account: accounts[1],
          getClient: () => client,
        }),
      ],
    })

    const httpServer = await Http.createServer(async (_req, res) => {
      res.writeHead(200)
      res.end('OK')
    })

    const response = await mppx.fetch(httpServer.url)
    expect(response.status).toBe(200)
    expect(await response.text()).toBe('OK')

    httpServer.close()
  })

  test('behavior: supports context', async () => {
    const mppx = Mppx.create({
      polyfill: false,
      methods: [
        tempo({
          getClient: () => client,
        }),
      ],
    })

    const httpServer = await Http.createServer(async (req, res) => {
      const result = await Mppx_server.toNodeListener(
        server.charge({
          amount: '1',
        }),
      )(req, res)
      if (result.status === 402) return
      res.end('OK')
    })

    const response = await mppx.fetch(httpServer.url, {
      context: { account: accounts[1] },
    })
    expect(response.status).toBe(200)

    httpServer.close()
  })
})

describe('polyfill', () => {
  test('default: polyfills globalThis.fetch', async () => {
    const originalFetch = globalThis.fetch

    Mppx.create({
      methods: [
        tempo({
          account: accounts[1],
          getClient: () => client,
        }),
      ],
    })

    expect(globalThis.fetch).not.toBe(originalFetch)

    const httpServer = await Http.createServer(async (req, res) => {
      const result = await Mppx_server.toNodeListener(
        server.charge({
          amount: '1',
        }),
      )(req, res)
      if (result.status === 402) return
      res.end('OK')
    })

    const response = await fetch(httpServer.url)
    expect(response.status).toBe(200)

    const receipt = Receipt.fromResponse(response)
    expect(receipt.status).toBe('success')

    httpServer.close()
  })

  test('behavior: polyfill false does not mutate globalThis.fetch', () => {
    const originalFetch = globalThis.fetch

    Mppx.create({
      polyfill: false,
      methods: [
        tempo({
          account: accounts[1],
          getClient: () => client,
        }),
      ],
    })

    expect(globalThis.fetch).toBe(originalFetch)
  })
})

describe('restore', () => {
  test('default: restores original fetch', () => {
    const originalFetch = globalThis.fetch

    Mppx.create({
      methods: [
        tempo({
          account: accounts[1],
          getClient: () => client,
        }),
      ],
    })

    expect(globalThis.fetch).not.toBe(originalFetch)

    Mppx.restore()

    expect(globalThis.fetch).toBe(originalFetch)
  })

  test('behavior: noop when not polyfilled', () => {
    const originalFetch = globalThis.fetch

    Mppx.create({
      polyfill: false,
      methods: [
        tempo({
          account: accounts[1],
          getClient: () => client,
        }),
      ],
    })

    Mppx.restore()

    expect(globalThis.fetch).toBe(originalFetch)
  })
})

describe('rawFetch', () => {
  test('default: returns the original fetch when polyfill is enabled', () => {
    const originalFetch = globalThis.fetch

    const mppx = Mppx.create({
      methods: [
        tempo({
          account: accounts[1],
          getClient: () => client,
        }),
      ],
    })

    expect(globalThis.fetch).not.toBe(originalFetch)
    expect(mppx.rawFetch).toBe(originalFetch)
  })

  test('behavior: returns the original fetch when polyfill is disabled', () => {
    const originalFetch = globalThis.fetch

    const mppx = Mppx.create({
      polyfill: false,
      methods: [
        tempo({
          account: accounts[1],
          getClient: () => client,
        }),
      ],
    })

    expect(mppx.rawFetch).toBe(originalFetch)
  })

  test('behavior: returns custom fetch when provided', () => {
    const customFetch = async () => new Response('custom')

    const mppx = Mppx.create({
      polyfill: false,
      fetch: customFetch as typeof globalThis.fetch,
      methods: [
        tempo({
          account: accounts[1],
          getClient: () => client,
        }),
      ],
    })

    expect(mppx.rawFetch).toBe(customFetch)
  })

  test('behavior: rawFetch does not intercept 402 responses', async () => {
    const mppx = Mppx.create({
      methods: [
        tempo({
          account: accounts[1],
          getClient: () => client,
        }),
      ],
    })

    const httpServer = await Http.createServer(async (req, res) => {
      const result = await Mppx_server.toNodeListener(
        server.charge({
          amount: '1',
        }),
      )(req, res)
      if (result.status === 402) return
      res.end('OK')
    })

    const response = await mppx.rawFetch(httpServer.url)
    expect(response.status).toBe(402)

    httpServer.close()
  })
})

import { describe, expect, test } from 'vp/test'

import {
  captureRequestBodyProbe,
  hasCapturedRequestBody,
  isSessionContentRequest,
  shouldChargePlainResponse,
} from './request-body.js'

describe('request-body', () => {
  describe('hasCapturedRequestBody', () => {
    test('returns true when the captured request recorded a typed body stream', () => {
      expect(
        hasCapturedRequestBody({
          hasBody: true,
          headers: new Headers({ 'content-type': 'application/json' }),
        }),
      ).toBe(true)
    })

    test('returns true for captured body streams without body headers', () => {
      expect(
        hasCapturedRequestBody({
          hasBody: true,
          headers: new Headers(),
        }),
      ).toBe(true)
    })

    test('returns true when content-length is non-zero', () => {
      expect(
        hasCapturedRequestBody({
          headers: new Headers({ 'content-length': '42' }),
        }),
      ).toBe(true)
    })

    test('returns true when transfer-encoding is present', () => {
      expect(
        hasCapturedRequestBody({
          headers: new Headers({ 'transfer-encoding': 'chunked' }),
        }),
      ).toBe(true)
    })

    test('returns false for bodyless requests without framing headers', () => {
      expect(
        hasCapturedRequestBody({
          hasBody: false,
          headers: new Headers(),
        }),
      ).toBe(false)
    })
  })

  describe('isSessionContentRequest', () => {
    test('treats GET requests as content requests', () => {
      expect(
        isSessionContentRequest({
          headers: new Headers(),
          method: 'GET',
        }),
      ).toBe(true)
    })

    test('treats HEAD requests as management requests', () => {
      expect(
        isSessionContentRequest({
          headers: new Headers(),
          method: 'HEAD',
        }),
      ).toBe(false)
    })

    test('treats POST requests with a typed body stream and no content-length as content requests', () => {
      expect(
        isSessionContentRequest({
          hasBody: true,
          headers: new Headers({ 'content-type': 'application/json' }),
          method: 'POST',
        }),
      ).toBe(true)
    })

    test('treats POST body streams without body headers as content requests', () => {
      expect(
        isSessionContentRequest({
          hasBody: true,
          headers: new Headers(),
          method: 'POST',
        }),
      ).toBe(true)
    })

    test('treats bodyless POST requests as management requests', () => {
      expect(
        isSessionContentRequest({
          hasBody: false,
          headers: new Headers(),
          method: 'POST',
        }),
      ).toBe(false)
    })

    test('treats bodyless POST requests with query parameters as content requests', () => {
      expect(
        isSessionContentRequest({
          hasBody: false,
          headers: new Headers(),
          method: 'POST',
          url: new URL('https://api.example.com/search?q=paid'),
        }),
      ).toBe(true)
    })
  })

  describe('shouldChargePlainResponse', () => {
    test('does not charge close or topUp actions', () => {
      const input = {
        hasBody: true,
        headers: new Headers(),
        method: 'POST',
      } as const

      expect(shouldChargePlainResponse(input, { action: 'close' })).toBe(false)
      expect(shouldChargePlainResponse(input, { action: 'topUp' })).toBe(false)
    })

    test('charges POST content requests detected via the typed body stream', () => {
      expect(
        shouldChargePlainResponse(
          {
            hasBody: true,
            headers: new Headers({ 'content-type': 'application/json' }),
            method: 'POST',
          },
          { action: 'voucher' },
        ),
      ).toBe(true)
    })

    test('does not charge bodyless POST management requests', () => {
      expect(
        shouldChargePlainResponse(
          {
            hasBody: false,
            headers: new Headers(),
            method: 'POST',
          },
          { action: 'voucher' },
        ),
      ).toBe(false)
    })

    test('charges voucher POSTs when runtime reports a body stream', () => {
      expect(
        shouldChargePlainResponse(
          {
            hasBody: true,
            headers: new Headers(),
            method: 'POST',
            url: new URL('https://api.example.com/session'),
          },
          { action: 'voucher' },
        ),
      ).toBe(true)
    })

    test('charges bodyless POST query requests', () => {
      expect(
        shouldChargePlainResponse(
          {
            hasBody: false,
            headers: new Headers(),
            method: 'POST',
            url: new URL('https://api.example.com/search?q=paid'),
          },
          { action: 'voucher' },
        ),
      ).toBe(true)
    })
  })

  describe('captureRequestBodyProbe', () => {
    test('captures body presence from Request.body', () => {
      const request = new Request('https://example.com', {
        body: JSON.stringify({ prompt: 'hello' }),
        method: 'POST',
      })

      const probe = captureRequestBodyProbe(request)
      expect(request.headers.get('content-length')).toBeNull()
      expect(probe).toEqual({
        headers: request.headers,
        hasBody: true,
        method: 'POST',
        url: new URL('https://example.com/'),
      })
    })
  })
})

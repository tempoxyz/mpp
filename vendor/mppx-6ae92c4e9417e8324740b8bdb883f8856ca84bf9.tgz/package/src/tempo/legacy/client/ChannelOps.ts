/**
 * Shared client-side channel operations.
 *
 * Provides the low-level helpers that both `session()`
 * and `sessionManager()` (orchestrator) rely on: escrow resolution, channel
 * ID computation, on-chain open/voucher/close payload construction, channel
 * recovery from on-chain state, and credential serialization.
 */
import { Hex } from 'ox'
import {
  type Address,
  encodeFunctionData,
  type Account as viem_Account,
  type Client as viem_Client,
} from 'viem'
import { prepareTransactionRequest, signTransaction } from 'viem/actions'
import { Abis } from 'viem/tempo'

import type { Challenge } from '../../../Challenge.js'
import * as Credential from '../../../Credential.js'
import { getAccountSignerAddress } from '../../internal/account.js'
import * as defaults from '../../internal/defaults.js'
import { escrowAbi, getOnChainChannel } from '../session/Chain.js'
import * as Channel from '../session/Channel.js'
import type { LegacySessionCredentialPayload } from '../session/Types.js'
import { signVoucher } from '../session/Voucher.js'

/** Cached channel metadata used by the legacy auto-driving session client. */
export type ChannelEntry = {
  /** Legacy contract-backed channel ID. */
  channelId: Hex.Hex
  /** Salt used to derive the channel ID. */
  salt: Hex.Hex
  /** Highest cumulative voucher amount locally authorized. */
  cumulativeAmount: bigint
  /** Escrow contract backing this channel. */
  escrowContract: Address
  /** Chain ID used for channel ID and voucher domain separation. */
  chainId: number
  /** Whether the client considers the channel reusable. */
  opened: boolean
}

function resolveVoucherSigner(
  account: viem_Account,
  voucherSigner?: viem_Account | undefined,
): viem_Account {
  return voucherSigner ?? account
}

/** Resolves the chain ID embedded in a legacy session challenge. */
export function resolveChainId(challenge: Challenge): number {
  const md = challenge.request.methodDetails as { chainId?: number } | undefined
  return md?.chainId ?? 0
}

/** Resolves the legacy escrow contract from local override, challenge hint, or defaults. */
export function resolveEscrow(
  challenge: { request: { methodDetails?: unknown } },
  chainId: number,
  escrowContractOverride?: Address,
): Address {
  const challengeEscrow = (challenge.request.methodDetails as { escrowContract?: string })
    ?.escrowContract as Address | undefined
  const escrow =
    escrowContractOverride ??
    challengeEscrow ??
    defaults.escrowContract[chainId as keyof typeof defaults.escrowContract]
  if (!escrow)
    throw new Error(
      'No `escrowContract` available. Provide it in parameters or ensure the server challenge includes it.',
    )
  return escrow
}

/** Serializes a legacy session credential with a payer DID source. */
export function serializeCredential(
  challenge: Challenge,
  payload: LegacySessionCredentialPayload,
  chainId: number,
  account: viem_Account,
): string {
  return Credential.serialize({
    challenge,
    payload,
    source: `did:pkh:eip155:${chainId}:${account.address}`,
  })
}

/** Creates a legacy cumulative voucher credential payload. */
export async function createVoucherPayload(
  client: viem_Client,
  account: viem_Account,
  channelId: Hex.Hex,
  cumulativeAmount: bigint,
  escrowContract: Address,
  chainId: number,
  voucherSigner?: viem_Account | undefined,
): Promise<LegacySessionCredentialPayload> {
  const signer = resolveVoucherSigner(account, voucherSigner)
  const signature = await signVoucher(
    client,
    account,
    { channelId, cumulativeAmount },
    escrowContract,
    chainId,
    signer,
  )
  return {
    action: 'voucher',
    channelId,
    cumulativeAmount: cumulativeAmount.toString(),
    signature,
  }
}

/** Creates a legacy cooperative close credential payload. */
export async function createClosePayload(
  client: viem_Client,
  account: viem_Account,
  channelId: Hex.Hex,
  cumulativeAmount: bigint,
  escrowContract: Address,
  chainId: number,
  voucherSigner?: viem_Account | undefined,
): Promise<LegacySessionCredentialPayload> {
  const signer = resolveVoucherSigner(account, voucherSigner)
  const signature = await signVoucher(
    client,
    account,
    { channelId, cumulativeAmount },
    escrowContract,
    chainId,
    signer,
  )
  return {
    action: 'close',
    channelId,
    cumulativeAmount: cumulativeAmount.toString(),
    signature,
  }
}

/** Creates a legacy open transaction credential payload and local channel entry. */
export async function createOpenPayload(
  client: viem_Client,
  account: viem_Account,
  options: {
    voucherSigner?: viem_Account | undefined
    escrowContract: Address
    payee: Address
    currency: Address
    deposit: bigint
    initialAmount: bigint
    chainId: number
    feePayer?: boolean | undefined
  },
): Promise<{ entry: ChannelEntry; payload: LegacySessionCredentialPayload }> {
  const { escrowContract, payee, currency, deposit, initialAmount, chainId, feePayer } = options
  const voucherSigner = resolveVoucherSigner(account, options.voucherSigner)
  const authorizedSigner = getAccountSignerAddress(voucherSigner)

  const salt = Hex.random(32)
  const channelId = Channel.computeId({
    authorizedSigner,
    chainId,
    escrowContract,
    payee,
    payer: account.address,
    salt,
    token: currency,
  })

  const approveData = encodeFunctionData({
    abi: Abis.tip20,
    functionName: 'approve',
    args: [escrowContract, deposit],
  })
  const openData = encodeFunctionData({
    abi: escrowAbi,
    functionName: 'open',
    args: [payee, currency, deposit, salt, authorizedSigner],
  })
  const validBefore = Math.floor(Date.now() / 1_000) + 25

  const prepared = await prepareTransactionRequest(client, {
    account,
    calls: [
      { to: currency, data: approveData },
      { to: escrowContract, data: openData },
    ],
    feeToken: currency,
    ...(feePayer ? { nonceKey: 'expiring', validBefore } : {}),
  } as never)
  // Estimate before enabling fee-payer mode so Tempo includes sender
  // signature and access-key verification costs in the gas budget.
  prepared.gas = (prepared.gas ?? 0n) + 5_000n
  if (feePayer) (prepared as Record<string, unknown>).feePayer = true
  const transaction = (await signTransaction(client, prepared as never)) as Hex.Hex

  const signature = await signVoucher(
    client,
    account,
    { channelId, cumulativeAmount: initialAmount },
    escrowContract,
    chainId,
    voucherSigner,
  )

  return {
    entry: {
      channelId,
      salt,
      cumulativeAmount: initialAmount,
      escrowContract,
      chainId,
      opened: true,
    },
    payload: {
      action: 'open',
      type: 'transaction',
      channelId,
      transaction,
      authorizedSigner,
      cumulativeAmount: initialAmount.toString(),
      signature,
    },
  }
}

/**
 * Attempt to recover an existing on-chain channel by reading its state.
 *
 * If the channel has a positive deposit and is not finalized, returns a
 * {@link ChannelEntry} with `cumulativeAmount` set to the on-chain settled
 * amount (the safe starting point for new vouchers).
 *
 * Returns `undefined` if the channel doesn't exist, has zero deposit,
 * or is already finalized.
 */
export async function tryRecoverChannel(
  client: viem_Client,
  escrowContract: Address,
  channelId: Hex.Hex,
  chainId: number,
): Promise<ChannelEntry | undefined> {
  try {
    const onChain = await getOnChainChannel(client, escrowContract, channelId)

    if (onChain.deposit > 0n && !onChain.finalized) {
      return {
        channelId,
        salt: '0x' as Hex.Hex,
        cumulativeAmount: onChain.settled,
        escrowContract,
        chainId,
        opened: true,
      }
    }
  } catch {}

  return undefined
}

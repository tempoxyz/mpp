import { describe, expect, test } from 'vp/test'

import * as Store from '../../Store.js'
import { fromStore } from './Store.js'
import type { SubscriptionRecord } from './Types.js'

const subscriptionId = 'sub_123'

function createRecord(overrides: Partial<SubscriptionRecord> = {}): SubscriptionRecord {
  return {
    amount: '10000000',
    billingAnchor: '2025-01-01T00:00:00.000Z',
    chainId: 4217,
    currency: '0x20c0000000000000000000000000000000000001',
    lastChargedPeriod: 0,
    lookupKey: 'user-1:plan:pro',
    periodCount: '1',
    periodUnit: 'day',
    recipient: '0x1234567890abcdef1234567890abcdef12345678',
    reference: `0x${'a'.repeat(64)}`,
    subscriptionExpires: '2026-01-01T00:00:00.000Z',
    subscriptionId,
    timestamp: '2025-01-01T00:00:00.000Z',
    ...overrides,
  }
}

describe('tempo subscription store', () => {
  test('prefixes all backing store keys when configured', async () => {
    const rawStore = Store.memory()
    const store = fromStore(Store.from(rawStore, { keyPrefix: 'tenant:' }))
    let finishActivation!: () => void
    const pendingActivation = new Promise<void>((resolve) => {
      finishActivation = resolve
    })
    let activationStarted!: () => void
    const activationStartedPromise = new Promise<void>((resolve) => {
      activationStarted = resolve
    })

    const activation = store.activate({
      challengeId: 'challenge-1',
      create: async () => {
        activationStarted()
        await pendingActivation
        return { subscription: createRecord() }
      },
      lookupKey: 'user-1:plan:pro',
    })
    await activationStartedPromise

    expect(await rawStore.get('tenant:tempo:subscription:credential:challenge-1')).not.toBeNull()
    expect(
      await rawStore.get('tenant:tempo:subscription:activation:user-1:plan:pro'),
    ).not.toBeNull()
    expect(await rawStore.get('tempo:subscription:credential:challenge-1')).toBeNull()

    finishActivation()
    expect((await activation).status).toBe('activated')
    await store.getOrCreateAccessKey('user-1:plan:pro')

    expect(await rawStore.get(`tenant:tempo:subscription:record:${subscriptionId}`)).not.toBeNull()
    expect(await rawStore.get('tenant:tempo:subscription:key:user-1:plan:pro')).toBe(subscriptionId)
    expect(
      await rawStore.get('tenant:tempo:subscription:access-key:user-1:plan:pro'),
    ).not.toBeNull()
    expect(await rawStore.get(`tempo:subscription:record:${subscriptionId}`)).toBeNull()
  })

  test('combines store prefix with custom key family prefixes', async () => {
    const rawStore = Store.memory()
    const store = fromStore(Store.from(rawStore, { keyPrefix: 'tenant:' }), {
      keyPrefix: 'lookup:',
      recordPrefix: 'record:',
    })

    await store.put(createRecord())

    expect(await rawStore.get(`tenant:record:${subscriptionId}`)).not.toBeNull()
    expect(await rawStore.get('tenant:lookup:user-1:plan:pro')).toBe(subscriptionId)
    expect(await rawStore.get(`record:${subscriptionId}`)).toBeNull()
  })

  test('rejects a replayed activation challenge', async () => {
    const store = fromStore(Store.memory())

    const first = await store.activate({
      challengeId: 'challenge-1',
      create: async () => ({ subscription: createRecord() }),
      lookupKey: 'user-1:plan:pro',
    })
    expect(first.status).toBe('activated')

    expect(
      await store.activate({
        challengeId: 'challenge-1',
        create: async () => ({ subscription: createRecord() }),
        lookupKey: 'user-1:plan:pro',
      }),
    ).toEqual({ status: 'replayed' })
  })

  test('tracks a resolved lookup key activation until committed', async () => {
    const store = fromStore(Store.memory())
    let finishActivation!: () => void
    const pendingActivation = new Promise<void>((resolve) => {
      finishActivation = resolve
    })

    const first = store.activate({
      challengeId: 'challenge-1',
      create: async () => {
        await pendingActivation
        return { subscription: createRecord() }
      },
      lookupKey: 'user-1:plan:pro',
    })
    expect(
      await store.activate({
        challengeId: 'challenge-2',
        create: async () => ({ subscription: createRecord() }),
        lookupKey: 'user-1:plan:pro',
      }),
    ).toEqual({ status: 'inFlight' })

    finishActivation()
    expect((await first).status).toBe('activated')
    expect((await store.getByKey('user-1:plan:pro'))?.subscriptionId).toBe(subscriptionId)
  })

  test('replaces a stale activation marker after the timeout', async () => {
    const store = fromStore(Store.memory(), { activationTimeoutMs: 0 })
    let finishActivation!: () => void
    const pendingActivation = new Promise<void>((resolve) => {
      finishActivation = resolve
    })

    const first = store.activate({
      challengeId: 'challenge-1',
      create: async () => {
        await pendingActivation
        return { subscription: createRecord({ reference: `0x${'b'.repeat(64)}` }) }
      },
      lookupKey: 'user-1:plan:pro',
    })

    const second = await store.activate({
      challengeId: 'challenge-2',
      create: async () => ({ subscription: createRecord() }),
      lookupKey: 'user-1:plan:pro',
    })
    expect(second.status).toBe('activated')

    finishActivation()
    expect(await first).toEqual({ status: 'claimMismatch' })
  })

  test('does not replace an activation marker that is committing', async () => {
    const rawStore = Store.memory()
    let store!: ReturnType<typeof fromStore>
    let nestedStatus: string | undefined
    let sawCommit = false
    const wrapped = {
      ...rawStore,
      async update(key, change) {
        const result = await rawStore.update(key, change)
        const marker = await rawStore.get(key)
        if (
          !sawCommit &&
          key === 'tempo:subscription:activation:user-1:plan:pro' &&
          marker &&
          typeof marker === 'object' &&
          'committingAt' in marker
        ) {
          sawCommit = true
          const nested = await store.activate({
            challengeId: 'challenge-2',
            create: async () => ({ subscription: createRecord({ subscriptionId: 'sub_2' }) }),
            lookupKey: 'user-1:plan:pro',
          })
          nestedStatus = nested.status
        }
        return result
      },
    } satisfies Store.AtomicStore<Record<string, unknown>>
    store = fromStore(wrapped, { activationTimeoutMs: 0 })

    const activated = await store.activate({
      challengeId: 'challenge-1',
      create: async () => ({ subscription: createRecord() }),
      lookupKey: 'user-1:plan:pro',
    })

    expect(activated.status).toBe('activated')
    expect(nestedStatus).toBe('inFlight')
    expect((await store.getByKey('user-1:plan:pro'))?.subscriptionId).toBe(subscriptionId)
  })

  test('keeps a superseded activation record for reconciliation', async () => {
    const store = fromStore(Store.memory(), { activationTimeoutMs: 0 })
    let finishActivation!: () => void
    const pendingActivation = new Promise<void>((resolve) => {
      finishActivation = resolve
    })

    const first = store.activate({
      challengeId: 'challenge-1',
      create: async () => {
        await pendingActivation
        return {
          subscription: createRecord({
            reference: `0x${'b'.repeat(64)}`,
            subscriptionId: 'sub_late',
          }),
        }
      },
      lookupKey: 'user-1:plan:pro',
    })

    const second = await store.activate({
      challengeId: 'challenge-2',
      create: async () => ({
        subscription: createRecord({ reference: `0x${'c'.repeat(64)}`, subscriptionId: 'sub_2' }),
      }),
      lookupKey: 'user-1:plan:pro',
    })
    expect(second.status).toBe('activated')

    finishActivation()
    expect(await first).toEqual({ status: 'claimMismatch' })
    expect((await store.get('sub_late'))?.canceledAt).toBeTruthy()
    expect((await store.getByKey('user-1:plan:pro'))?.subscriptionId).toBe('sub_2')
  })

  test('rechecks the lookup key after claiming activation', async () => {
    const rawStore = Store.memory()
    const seeded = fromStore(rawStore)
    const store = fromStore({
      ...rawStore,
      async update(key, change) {
        const result = await rawStore.update(key, change)
        if (key === 'tempo:subscription:activation:user-1:plan:pro') {
          await seeded.put(createRecord())
        }
        return result
      },
    })
    let createCalled = false

    const activated = await store.activate({
      challengeId: 'challenge-1',
      create: async () => {
        createCalled = true
        return { subscription: createRecord({ subscriptionId: 'sub_new' }) }
      },
      isReusable: () => true,
      lookupKey: 'user-1:plan:pro',
    })

    expect(activated).toEqual({ status: 'existing', subscription: createRecord() })
    expect(createCalled).toBe(false)
  })

  test('clears the activation marker when creation fails', async () => {
    const store = fromStore(Store.memory())

    await expect(
      store.activate({
        challengeId: 'challenge-1',
        create: async () => {
          throw new Error('activation failed')
        },
        lookupKey: 'user-1:plan:pro',
      }),
    ).rejects.toThrow('activation failed')

    const retried = await store.activate({
      challengeId: 'challenge-2',
      create: async () => ({ subscription: createRecord() }),
      lookupKey: 'user-1:plan:pro',
    })
    expect(retried.status).toBe('activated')
  })

  test('tracks an in-flight renewal and commits it once', async () => {
    const store = fromStore(Store.memory())
    await store.put(createRecord())

    const renewed = await store.renew({
      inFlightReference: '0xrenewal',
      periodIndex: 1,
      renew: async ({ inFlightReference, subscription }) => {
        expect(inFlightReference).toBe('0xrenewal')
        return {
          subscription: {
            ...subscription,
            lastChargedPeriod: 1,
            reference: `0x${'b'.repeat(64)}`,
          },
        }
      },
      subscriptionId,
    })
    expect(renewed.status).toBe('renewed')
    expect((await store.get(subscriptionId))?.inFlightPeriod).toBe(undefined)

    expect(
      await store.renew({
        inFlightReference: '0xmissing',
        periodIndex: 2,
        renew: async () => ({ subscription: createRecord() }),
        subscriptionId: 'sub_missing',
      }),
    ).toEqual({ status: 'missing' })

    const committed = await store.get(subscriptionId)
    expect(committed?.lastChargedPeriod).toBe(1)
    expect(committed?.inFlightPeriod).toBe(undefined)

    const charged = await store.renew({
      inFlightReference: '0xrenewal',
      periodIndex: 1,
      renew: async () => ({ subscription: createRecord() }),
      subscriptionId,
    })
    expect(charged.status).toBe('charged')
  })

  test('returns in-flight for a duplicate renewal period', async () => {
    const store = fromStore(Store.memory())
    await store.put(createRecord())
    let finishRenewal!: () => void
    const pendingRenewal = new Promise<void>((resolve) => {
      finishRenewal = resolve
    })

    const first = store.renew({
      inFlightReference: '0xrenewal',
      periodIndex: 1,
      renew: async ({ subscription }) => {
        await pendingRenewal
        return { subscription }
      },
      subscriptionId,
    })

    const duplicate = await store.renew({
      inFlightReference: '0xrenewal',
      periodIndex: 1,
      renew: async ({ subscription }) => ({ subscription }),
      subscriptionId,
    })
    expect(duplicate.status).toBe('inFlight')

    finishRenewal()
    expect((await first).status).toBe('renewed')
  })

  test('returns in-flight when any non-stale renewal is active', async () => {
    const store = fromStore(Store.memory())
    await store.put(
      createRecord({ inFlightPeriod: 1, inFlightStartedAt: new Date().toISOString() }),
    )
    let renewCalled = false

    const renewal = await store.renew({
      inFlightReference: '0xrenewal',
      periodIndex: 2,
      renew: async ({ subscription }) => {
        renewCalled = true
        return { subscription }
      },
      subscriptionId,
    })

    expect(renewal.status).toBe('inFlight')
    expect(renewCalled).toBe(false)
  })

  test('replaces a stale in-flight renewal after the timeout', async () => {
    const store = fromStore(Store.memory(), { renewalTimeoutMs: 0 })
    await store.put(createRecord())
    let finishRenewal!: () => void
    const pendingRenewal = new Promise<void>((resolve) => {
      finishRenewal = resolve
    })

    const first = store.renew({
      inFlightReference: '0xfirst',
      periodIndex: 1,
      renew: async ({ subscription }) => {
        await pendingRenewal
        return { subscription }
      },
      subscriptionId,
    })

    const second = await store.renew({
      inFlightReference: '0xsecond',
      periodIndex: 1,
      renew: async ({ subscription }) => ({
        subscription: {
          ...subscription,
          reference: `0x${'b'.repeat(64)}`,
        },
      }),
      subscriptionId,
    })
    expect(second.status).toBe('renewed')

    finishRenewal()
    expect(await first).toEqual({ status: 'claimMismatch' })
  })

  test('stale renewal cannot commit over a newer in-flight attempt', async () => {
    const store = fromStore(Store.memory(), { renewalTimeoutMs: 0 })
    await store.put(createRecord())
    let finishFirst!: () => void
    let finishSecond!: () => void
    const firstPending = new Promise<void>((resolve) => {
      finishFirst = resolve
    })
    const secondPending = new Promise<void>((resolve) => {
      finishSecond = resolve
    })

    const first = store.renew({
      inFlightReference: '0xfirst',
      periodIndex: 1,
      renew: async ({ subscription }) => {
        await firstPending
        return {
          subscription: {
            ...subscription,
            reference: `0x${'b'.repeat(64)}`,
          },
        }
      },
      subscriptionId,
    })

    const second = store.renew({
      inFlightReference: '0xsecond',
      periodIndex: 1,
      renew: async ({ subscription }) => {
        await secondPending
        return {
          subscription: {
            ...subscription,
            reference: `0x${'c'.repeat(64)}`,
          },
        }
      },
      subscriptionId,
    })

    finishFirst()
    expect(await first).toEqual({ status: 'claimMismatch' })
    expect((await store.get(subscriptionId))?.inFlightReference).toBe('0xsecond')

    finishSecond()
    expect((await second).status).toBe('renewed')
    expect((await store.get(subscriptionId))?.reference).toBe(`0x${'c'.repeat(64)}`)
  })

  test('stale renewal failure cannot clear a newer in-flight attempt', async () => {
    const store = fromStore(Store.memory(), { renewalTimeoutMs: 0 })
    await store.put(createRecord())
    let rejectFirst!: () => void
    let finishSecond!: () => void
    const firstPending = new Promise<void>((_resolve, reject) => {
      rejectFirst = () => reject(new Error('first failed'))
    })
    const secondPending = new Promise<void>((resolve) => {
      finishSecond = resolve
    })

    const first = store.renew({
      inFlightReference: '0xfirst',
      periodIndex: 1,
      renew: async ({ subscription }) => {
        await firstPending
        return { subscription }
      },
      subscriptionId,
    })

    const second = store.renew({
      inFlightReference: '0xsecond',
      periodIndex: 1,
      renew: async ({ subscription }) => {
        await secondPending
        return { subscription }
      },
      subscriptionId,
    })

    rejectFirst()
    await expect(first).rejects.toThrow('first failed')
    expect((await store.get(subscriptionId))?.inFlightReference).toBe('0xsecond')

    finishSecond()
    expect((await second).status).toBe('renewed')
  })

  test('clears an in-flight renewal after failure', async () => {
    const store = fromStore(Store.memory())
    await store.put(createRecord())

    await expect(
      store.renew({
        inFlightReference: '0xrenewal',
        periodIndex: 1,
        renew: async () => {
          throw new Error('renewal failed')
        },
        subscriptionId,
      }),
    ).rejects.toThrow('renewal failed')

    expect((await store.get(subscriptionId))?.inFlightPeriod).toBe(undefined)
    expect(
      (
        await store.renew({
          inFlightReference: '0xrenewal',
          periodIndex: 1,
          renew: async ({ subscription }) => ({ subscription }),
          subscriptionId,
        })
      ).status,
    ).toBe('renewed')
  })

  test('preserves cancellation that lands during an in-flight renewal', async () => {
    const store = fromStore(Store.memory())
    await store.put(createRecord())

    const renewed = await store.renew({
      inFlightReference: '0xrenewal',
      periodIndex: 1,
      renew: async ({ subscription }) => {
        await store.put({
          ...subscription,
          canceledAt: '2025-01-02T00:00:00.000Z',
        })
        return {
          subscription: {
            ...subscription,
            lastChargedPeriod: 1,
            reference: `0x${'b'.repeat(64)}`,
          },
        }
      },
      subscriptionId,
    })
    expect(renewed.status).toBe('renewed')

    const committed = await store.get(subscriptionId)
    expect(committed?.canceledAt).toBe('2025-01-02T00:00:00.000Z')
    expect(committed?.lastChargedPeriod).toBe(1)
    expect(committed?.inFlightPeriod).toBe(undefined)
  })

  test('does not renew a superseded subscription record', async () => {
    const store = fromStore(Store.memory())
    await store.put(createRecord({ subscriptionId: 'sub_old' }))
    await store.put(createRecord({ reference: `0x${'b'.repeat(64)}`, subscriptionId: 'sub_new' }))
    let renewCalled = false

    const renewal = await store.renew({
      inFlightReference: '0xrenewal',
      periodIndex: 1,
      renew: async ({ subscription }) => {
        renewCalled = true
        return { subscription }
      },
      subscriptionId: 'sub_old',
    })

    expect(renewal.status).toBe('superseded')
    expect(renewCalled).toBe(false)
    expect((await store.getByKey('user-1:plan:pro'))?.subscriptionId).toBe('sub_new')
  })

  test('does not reclaim lookup ownership when superseded during renewal', async () => {
    const store = fromStore(Store.memory())
    await store.put(createRecord({ subscriptionId: 'sub_old' }))

    const renewal = await store.renew({
      inFlightReference: '0xrenewal',
      periodIndex: 1,
      renew: async ({ subscription }) => {
        await store.put(
          createRecord({ reference: `0x${'c'.repeat(64)}`, subscriptionId: 'sub_new' }),
        )
        return {
          subscription: {
            ...subscription,
            reference: `0x${'b'.repeat(64)}`,
          },
        }
      },
      subscriptionId: 'sub_old',
    })

    expect(renewal.status).toBe('superseded')
    expect((await store.getByKey('user-1:plan:pro'))?.subscriptionId).toBe('sub_new')
  })
})

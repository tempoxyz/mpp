import * as node_http from 'node:http'

import { Challenge, Constants, Credential } from 'mppx'
import { Mppx as Mppx_server, tempo as tempo_server } from 'mppx/server'
import {
  type Address,
  createClient,
  custom,
  defineChain,
  encodeAbiParameters,
  encodeEventTopics,
  encodeFunctionData,
  encodeFunctionResult,
  type Hex,
  zeroAddress,
} from 'viem'
import { privateKeyToAccount } from 'viem/accounts'
import { Transaction } from 'viem/tempo'
import { describe, expect, test, vi } from 'vp/test'
import { WebSocket, WebSocketServer } from 'ws'
import * as Http from '~test/Http.js'

import * as NodeRequest from '../../../server/Request.js'
import * as Store from '../../../Store.js'
import { charge as clientCharge } from '../../client/Charge.js'
import * as Methods from '../../Methods.js'
import * as ClientOps from '../client/ChannelOps.js'
import { sessionManager as precompileSessionManager } from '../client/SessionManager.js'
import * as Channel from '../precompile/Channel.js'
import { escrowAbi } from '../precompile/escrow.abi.js'
import { tip20ChannelEscrow } from '../precompile/Protocol.js'
import { deserializeSessionReceipt } from '../precompile/Protocol.js'
import type { SessionReceipt } from '../precompile/Protocol.js'
import type { SessionCredentialPayload } from '../precompile/Protocol.js'
import * as Types from '../precompile/Protocol.js'
import * as Voucher from '../precompile/Voucher.js'
import * as ChannelStore from './ChannelStore.js'
import { charge, session, type ResolveSessionChannelId } from './Session.js'
import * as TempoWs from './Ws.js'

const payer = privateKeyToAccount(
  '0xac0974bec39a17e36ba6a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80',
)
const wrongPayer = privateKeyToAccount(
  '0x59c6995e998f97a5a0044966f094538a009d74290f5811cfba6a6b4d238ff944',
)
const chainId = 42431
const payee = '0x0000000000000000000000000000000000000002' as Address
const token = '0x0000000000000000000000000000000000000003' as Address
const wrongTarget = '0x0000000000000000000000000000000000000004' as Address
const testChain = defineChain({
  id: chainId,
  name: 'Tempo Test',
  nativeCurrency: { name: 'Tempo', symbol: 'TEMPO', decimals: 18 },
  rpcUrls: { default: { http: ['http://localhost'] } },
})

type RpcCall = { method: string; params?: unknown }
type ChainState = { settled: bigint; deposit: bigint; closeRequestedAt: number }
type SessionRequest = ReturnType<typeof Methods.session.schema.request.parse>

function channelStore(store: Store.Store | Store.AtomicStore): ChannelStore.ChannelStore {
  return ChannelStore.fromStore(store)
}

function createSigningClient(account = payer) {
  return createClient({
    account,
    chain: testChain,
    transport: custom({
      async request(args) {
        if (args.method === 'eth_chainId') return `0x${chainId.toString(16)}`
        if (args.method === 'eth_getTransactionCount') return '0x0'
        if (args.method === 'eth_estimateGas') return '0x5208'
        if (args.method === 'eth_maxPriorityFeePerGas') return '0x1'
        if (args.method === 'eth_getBlockByNumber') return { baseFeePerGas: '0x1' }
        throw new Error(`unexpected signing rpc request: ${args.method}`)
      },
    }),
  })
}

function createServerClient(
  calls: RpcCall[] = [],
  account: typeof payer | null = payer,
  _eventChannelId: Hex = `0x${'00'.repeat(32)}` as Hex,
  options: {
    descriptor?: Channel.ChannelDescriptor
    receipt?: Record<string, unknown>
    state?: ChainState
  } = {},
) {
  return createClient({
    ...(account ? { account } : {}),
    chain: testChain,
    transport: custom({
      async request(args) {
        calls.push(args)
        if (args.method === 'eth_chainId') return `0x${chainId.toString(16)}`
        if (args.method === 'eth_getTransactionCount') return '0x0'
        if (args.method === 'eth_estimateGas') return '0x5208'
        if (args.method === 'eth_maxPriorityFeePerGas') return '0x1'
        if (args.method === 'eth_getBlockByNumber') return { baseFeePerGas: '0x1' }
        if (args.method === 'eth_sendRawTransaction') return `0x${'aa'.repeat(32)}`
        if (args.method === 'eth_getTransactionReceipt') return options.receipt ?? null
        if (args.method === 'eth_sendTransaction') return `0x${'bb'.repeat(32)}`
        if (args.method === 'eth_call') {
          const state = options.state ?? { settled: 100n, deposit: 1_000n, closeRequestedAt: 0 }
          const data = (args.params as [{ data?: Hex }])[0].data
          const getChannelSelector = options.descriptor
            ? encodeFunctionData({
                abi: escrowAbi,
                functionName: 'getChannel',
                args: [options.descriptor],
              }).slice(0, 10)
            : undefined
          if (data && getChannelSelector && data.slice(0, 10) === getChannelSelector)
            return encodeFunctionResult({
              abi: escrowAbi,
              functionName: 'getChannel',
              result: { descriptor: options.descriptor!, state },
            })
          return encodeFunctionResult({
            abi: escrowAbi,
            functionName: 'getChannelState',
            result: state,
          })
        }
        throw new Error(`unexpected rpc request: ${args.method}`)
      },
    }),
  })
}

function createStateClient(
  account: typeof payer | null = payer,
  state: ChainState = {
    settled: 0n,
    deposit: 1_000n,
    closeRequestedAt: 0,
  },
) {
  return createClient({
    ...(account ? { account } : {}),
    chain: testChain,
    transport: custom({
      async request(args) {
        if (args.method === 'eth_chainId') return `0x${chainId.toString(16)}`
        if (args.method === 'eth_call')
          return encodeFunctionResult({
            abi: escrowAbi,
            functionName: 'getChannelState',
            result: state,
          })
        if (args.method === 'eth_getTransactionCount') return '0x0'
        if (args.method === 'eth_estimateGas') return '0x5208'
        if (args.method === 'eth_maxPriorityFeePerGas') return '0x1'
        if (args.method === 'eth_getBlockByNumber') return { baseFeePerGas: '0x1' }
        throw new Error(`unexpected rpc request: ${args.method}`)
      },
    }),
  })
}

function createServer(parameters: Partial<session.Parameters> = {}) {
  const rawStore = Store.memory()
  const rpcCalls: RpcCall[] = []
  const serverClient = createServerClient(rpcCalls)
  const method = session({
    amount: '1',
    chainId,
    currency: token,
    decimals: 0,
    recipient: payee,
    store: rawStore,
    unitType: 'request',
    getClient: () => serverClient,
    ...parameters,
  })
  return { method, store: channelStore(rawStore), rpcCalls }
}

function makeChallenge(
  channelId?: Hex,
  options: { operator?: Address | undefined } = {},
): Challenge.Challenge<SessionRequest, 'session', 'tempo'> {
  return {
    id: 'challenge-id',
    realm: 'api.example.com',
    method: 'tempo',
    intent: 'session',
    request: makeRequest(channelId, options),
  } as Challenge.Challenge<SessionRequest, 'session', 'tempo'>
}

function makeRequest(
  channelId?: Hex,
  options: { operator?: Address | undefined } = {},
): SessionRequest {
  return {
    amount: '100',
    currency: token,
    recipient: payee,
    unitType: 'request',
    methodDetails: {
      chainId,
      escrowContract: tip20ChannelEscrow,
      ...(channelId && { channelId }),
      ...(options.operator ? { operator: options.operator } : {}),
    },
  }
}

type VerifyRequest = Parameters<NonNullable<ReturnType<typeof session>['verify']>>[0]['request']

function verifyRequest(
  channelId?: Hex,
  options: { operator?: Address | undefined } = {},
): VerifyRequest {
  // `verify()` receives the HMAC-bound canonical challenge request. The public
  // request schema input still includes parse-only fields like `decimals`, so
  // keep this test bridge in one place instead of casting every verification.
  return makeRequest(channelId, options) as unknown as VerifyRequest
}

function verifyRequestWithFeePayer(channelId: Hex, feePayer: typeof payer): VerifyRequest {
  const request = makeRequest(channelId)
  return {
    ...request,
    feePayer,
    methodDetails: {
      ...request.methodDetails,
      feePayer: true,
    },
  } as unknown as VerifyRequest
}

let saltCounter = 0

async function createOpenPayload(
  parameters: {
    deposit?: bigint | undefined
    initialAmount?: bigint | undefined
    escrow?: Address | undefined
    account?: typeof payer | undefined
    operator?: Address | undefined
    authorizedSigner?: Address | undefined
  } = {},
): Promise<Extract<SessionCredentialPayload, { action: 'open' }>> {
  const account = parameters.account ?? payer
  const escrow = parameters.escrow ?? tip20ChannelEscrow
  const initialAmount = Types.uint96(parameters.initialAmount ?? 100n)
  const deposit = Types.uint96(parameters.deposit ?? 1_000n)
  const salt = `0x${(++saltCounter).toString(16).padStart(64, '0')}` as Hex
  const operator = parameters.operator ?? zeroAddress
  const authorizedSigner = parameters.authorizedSigner ?? account.address
  const data = encodeFunctionData({
    abi: escrowAbi,
    functionName: 'open',
    args: [payee, operator, token, deposit, salt, authorizedSigner],
  })
  const signingClient = createSigningClient(account)
  const transaction = (await Transaction.serialize({
    chainId,
    calls: [{ to: escrow, data }],
    feeToken: token,
    nonce: 0,
  })) as Hex
  const expiringNonceHash = Channel.computeExpiringNonceHash(
    Transaction.deserialize(
      transaction as Transaction.TransactionSerializedTempo,
    ) as Channel.ExpiringNonceTransaction,
    { sender: account.address },
  )
  const descriptor = {
    payer: account.address,
    payee,
    operator,
    token,
    salt,
    authorizedSigner,
    expiringNonceHash,
  } satisfies Channel.ChannelDescriptor
  const channelId = Channel.computeId({ ...descriptor, chainId, escrow })
  const signature = await Voucher.signVoucher(
    signingClient,
    account,
    { channelId, cumulativeAmount: initialAmount },
    escrow,
    chainId,
  )
  return {
    action: 'open',
    type: 'transaction',
    channelId,
    transaction,
    signature,
    descriptor,
    cumulativeAmount: initialAmount.toString(),
    authorizedSigner: descriptor.authorizedSigner,
  }
}

function transactionReceipt(logs: readonly Record<string, unknown>[]) {
  return {
    blockHash: `0x${'01'.repeat(32)}`,
    blockNumber: '0x1',
    contractAddress: null,
    cumulativeGasUsed: '0x1',
    effectiveGasPrice: '0x1',
    from: payer.address,
    gasUsed: '0x1',
    logs,
    logsBloom: `0x${'00'.repeat(256)}`,
    status: '0x1',
    to: tip20ChannelEscrow,
    transactionHash: `0x${'aa'.repeat(32)}`,
    transactionIndex: '0x0',
    type: '0x76',
  }
}

function openedLog(
  payload: Extract<SessionCredentialPayload, { action: 'open' }>,
  deposit = 1_000n,
) {
  return {
    address: tip20ChannelEscrow,
    data: encodeAbiParameters(
      [
        { type: 'address' },
        { type: 'address' },
        { type: 'address' },
        { type: 'bytes32' },
        { type: 'bytes32' },
        { type: 'uint96' },
      ],
      [
        payload.descriptor.operator,
        payload.descriptor.token,
        payload.descriptor.authorizedSigner,
        payload.descriptor.salt,
        payload.descriptor.expiringNonceHash,
        deposit,
      ],
    ),
    topics: encodeEventTopics({
      abi: escrowAbi,
      eventName: 'ChannelOpened',
      args: {
        channelId: payload.channelId,
        payer: payload.descriptor.payer,
        payee: payload.descriptor.payee,
      },
    }),
  }
}

function settledLog(channelId: Hex, newSettled: bigint) {
  return {
    address: tip20ChannelEscrow,
    data: encodeAbiParameters(
      [{ type: 'uint96' }, { type: 'uint96' }, { type: 'uint96' }],
      [newSettled, newSettled, newSettled],
    ),
    topics: encodeEventTopics({
      abi: escrowAbi,
      eventName: 'Settled',
      args: { channelId, payer: payer.address, payee: payer.address },
    }),
  }
}

function closedLog(channelId: Hex, settledToPayee: bigint, refundedToPayer: bigint) {
  return {
    address: tip20ChannelEscrow,
    data: encodeAbiParameters(
      [{ type: 'uint96' }, { type: 'uint96' }],
      [settledToPayee, refundedToPayer],
    ),
    topics: encodeEventTopics({
      abi: escrowAbi,
      eventName: 'ChannelClosed',
      args: { channelId, payer: payer.address, payee: payer.address },
    }),
  }
}

function topUpLog(
  payload: Extract<SessionCredentialPayload, { action: 'topUp' }>,
  newDeposit: bigint,
) {
  return {
    address: tip20ChannelEscrow,
    data: encodeAbiParameters([{ type: 'uint96' }, { type: 'uint96' }], [1_000n, newDeposit]),
    topics: encodeEventTopics({
      abi: escrowAbi,
      eventName: 'TopUp',
      args: { channelId: payload.channelId, payer: payer.address, payee },
    }),
  }
}

async function createTopUpPayload(
  descriptor: Channel.ChannelDescriptor,
  additionalDeposit = 500n,
): Promise<Extract<SessionCredentialPayload, { action: 'topUp' }>> {
  const data = encodeFunctionData({
    abi: escrowAbi,
    functionName: 'topUp',
    args: [descriptor, Types.uint96(additionalDeposit)],
  })
  const transaction = (await Transaction.serialize({
    chainId,
    calls: [{ to: tip20ChannelEscrow, data }],
    feeToken: token,
    nonce: 0,
  })) as Hex
  const channelId = Channel.computeId({ ...descriptor, chainId, escrow: tip20ChannelEscrow })
  return {
    action: 'topUp',
    type: 'transaction',
    channelId,
    descriptor,
    transaction,
    additionalDeposit: additionalDeposit.toString(),
  }
}

async function persistPrecompileChannel(
  store: ChannelStore.ChannelStore,
  payload: Extract<SessionCredentialPayload, { action: 'open' }>,
  overrides: Partial<ChannelStore.State> = {},
) {
  await store.updateChannel(payload.channelId, () => ({
    backend: 'precompile',
    channelId: payload.channelId,
    chainId,
    escrowContract: tip20ChannelEscrow,
    closeRequestedAt: 0n,
    payer: payload.descriptor.payer,
    payee,
    token,
    authorizedSigner: payload.descriptor.authorizedSigner,
    deposit: 1_000n,
    settledOnChain: 0n,
    highestVoucherAmount: BigInt(payload.cumulativeAmount),
    highestVoucher: {
      channelId: payload.channelId,
      cumulativeAmount: BigInt(payload.cumulativeAmount),
      signature: payload.signature,
    },
    spent: 0n,
    units: 0,
    finalized: false,
    createdAt: new Date(0).toISOString(),
    descriptor: payload.descriptor,
    operator: payload.descriptor.operator,
    salt: payload.descriptor.salt,
    expiringNonceHash: payload.descriptor.expiringNonceHash,
    ...overrides,
  }))
}

describe('precompile server session unit guardrails', () => {
  test('request marks TIP-1034 session challenges', async () => {
    const { method } = createServer()

    const challengeRequest = await method.request!({
      credential: null,
      request: {
        amount: '1',
        currency: token,
        decimals: 0,
        recipient: payee,
        unitType: 'request',
      },
    } as never)

    expect(challengeRequest.sessionProtocol).toBe(Constants.SessionProtocols.v2)
  })

  test('request normalizes fee-payer to boolean for challenge issuance and account for verification', async () => {
    const { method } = createServer({ feePayer: wrongPayer })

    const challengeRequest = await method.request!({
      credential: null,
      request: {
        amount: '1',
        currency: token,
        decimals: 0,
        recipient: payee,
        unitType: 'request',
      },
    } as never)
    expect(challengeRequest.feePayer).toBe(true)

    const verificationRequest = await method.request!({
      credential: { challenge: {}, payload: {} } as never,
      request: {
        amount: '1',
        currency: token,
        decimals: 0,
        feePayer: payer,
        recipient: payee,
        unitType: 'request',
      },
    } as never)
    expect(verificationRequest.feePayer).toBe(payer)
  })

  test('request allows callers to explicitly disable precompile fee-payer', async () => {
    const { method } = createServer({ feePayer: wrongPayer })

    const challengeRequest = await method.request!({
      credential: null,
      request: {
        amount: '1',
        currency: token,
        decimals: 0,
        feePayer: false,
        recipient: payee,
        unitType: 'request',
      },
    } as never)
    expect(challengeRequest.feePayer).toBeUndefined()

    const verificationRequest = await method.request!({
      credential: { challenge: {}, payload: {} } as never,
      request: {
        amount: '1',
        currency: token,
        decimals: 0,
        feePayer: false,
        recipient: payee,
        unitType: 'request',
      },
    } as never)
    expect(verificationRequest.feePayer).toBe(false)
  })

  test('request returns a server session snapshot for a known precompile channel', async () => {
    const { method, store } = createServer()
    const openPayload = await createOpenPayload({ initialAmount: 100n })
    await persistPrecompileChannel(store, openPayload, {
      highestVoucherAmount: 250n,
      spent: 200n,
      units: 2,
    })

    const request = await method.request!({
      credential: {
        challenge: {},
        payload: {},
      } as never,
      request: {
        amount: '1',
        channelId: openPayload.channelId,
        currency: token,
        decimals: 0,
        recipient: payee,
        unitType: 'request',
      },
    } as never)

    expect(request.sessionSnapshot).toEqual({
      acceptedCumulative: '250',
      chainId,
      channelId: openPayload.channelId,
      closeRequestedAt: undefined,
      deposit: '1000',
      descriptor: openPayload.descriptor,
      escrow: tip20ChannelEscrow,
      requiredCumulative: '201',
      settled: '0',
      spent: '200',
      units: 2,
    })
  })

  test('request can resolve a server session snapshot from request identity', async () => {
    const openPayload = await createOpenPayload({ initialAmount: 100n })
    const { method, store } = createServer({
      resolveChannelId({ request, credential, paymentRequest, store: hookStore }) {
        expect(request?.headers.get('cookie')).toBe('sid=session-1')
        expect(credential).toBeNull()
        expect(paymentRequest.unitType).toBe('request')
        expect(hookStore).toBe(store)
        return openPayload.channelId
      },
    })
    await persistPrecompileChannel(store, openPayload, {
      highestVoucherAmount: 250n,
      spent: 200n,
      units: 2,
    })

    const request = await method.request!({
      capturedRequest: {
        hasBody: false,
        headers: new Headers({ cookie: 'sid=session-1' }),
        method: 'GET',
        url: new URL('https://api.example.com/resource'),
      },
      credential: null,
      request: {
        amount: '1',
        currency: token,
        decimals: 0,
        recipient: payee,
        unitType: 'request',
      },
    } as never)

    expect(request.sessionSnapshot).toMatchObject({
      channelId: openPayload.channelId,
      descriptor: openPayload.descriptor,
      requiredCumulative: '201',
      spent: '200',
    })
  })

  test('request prefers explicit channel ID over custom channel resolver', async () => {
    const openPayload = await createOpenPayload({ initialAmount: 100n })
    const { method, store } = createServer({
      resolveChannelId() {
        throw new Error('unexpected resolver call')
      },
    })
    await persistPrecompileChannel(store, openPayload)

    const request = await method.request!({
      credential: null,
      request: {
        amount: '1',
        channelId: openPayload.channelId,
        currency: token,
        decimals: 0,
        recipient: payee,
        unitType: 'request',
      },
    } as never)

    expect(request.sessionSnapshot?.channelId).toBe(openPayload.channelId)
  })

  test('request uses zero effective amount for non-content snapshot hints', async () => {
    const { method, store } = createServer()
    const openPayload = await createOpenPayload({ initialAmount: 100n })
    await persistPrecompileChannel(store, openPayload, {
      highestVoucherAmount: 250n,
      spent: 250n,
      units: 2,
    })

    const request = await method.request!({
      capturedRequest: {
        hasBody: false,
        headers: new Headers(),
        method: 'HEAD',
        url: new URL('https://api.example.com/resource'),
      },
      credential: {
        challenge: {},
        payload: {},
      } as never,
      request: {
        amount: '1',
        channelId: openPayload.channelId,
        currency: token,
        decimals: 0,
        recipient: payee,
        unitType: 'request',
      },
    } as never)

    expect(request.sessionSnapshot).toMatchObject({
      acceptedCumulative: '250',
      requiredCumulative: '250',
      spent: '250',
    })
  })

  test('request throws when resolved precompile client chain mismatches requested chain', async () => {
    const { method } = createServer({ chainId: 1 })

    await expect(
      method.request!({
        credential: null,
        request: {
          amount: '1',
          chainId: 1,
          currency: token,
          decimals: 0,
          recipient: payee,
          unitType: 'request',
        },
      } as never),
    ).rejects.toThrow('Client not configured with chainId 1.')
  })

  test('rejects open transactions targeting the wrong address', async () => {
    const { method } = createServer()
    const payload = await createOpenPayload({ escrow: wrongTarget })

    await expect(
      method.verify({
        credential: { challenge: makeChallenge(payload.channelId), payload },
        request: verifyRequest(payload.channelId),
      }),
    ).rejects.toThrow(/descriptor does not match channelId|wrong address/)
  })

  test('rejects smuggled extra calls in open transactions', async () => {
    const { method } = createServer()
    const payload = await createOpenPayload()
    const tampered = await createOpenPayload()

    // Reuse a valid descriptor/signature, but submit a transaction whose calls
    // do not correspond to that descriptor. This exercises the same one-call /
    // smuggling guard as legacy server session tests without requiring a live
    // chain-backed precompile.
    const smuggled = { ...payload, transaction: tampered.transaction }

    await expect(
      method.verify({
        credential: {
          challenge: makeChallenge(payload.channelId),
          payload: smuggled,
        },
        request: verifyRequest(payload.channelId),
      }),
    ).rejects.toThrow(/does not match/)
  })

  test('rejects descriptors that do not match the challenge channel ID', async () => {
    const { method } = createServer()
    const payload = await createOpenPayload()
    const badDescriptor = {
      ...payload.descriptor,
      token: '0x0000000000000000000000000000000000000005' as Address,
    }

    await expect(
      method.verify({
        credential: {
          challenge: makeChallenge(payload.channelId),
          payload: { ...payload, descriptor: badDescriptor },
        },
        request: verifyRequest(payload.channelId),
      }),
    ).rejects.toThrow(/descriptor does not match channelId/)
  })

  test('rejects invalid initial voucher signatures', async () => {
    const { method } = createServer()
    const payload = await createOpenPayload()
    const badSignaturePayload = {
      ...payload,
      signature: (await createOpenPayload({ account: wrongPayer })).signature,
    }

    await expect(
      method.verify({
        credential: {
          challenge: makeChallenge(payload.channelId),
          payload: badSignaturePayload,
        },
        request: verifyRequest(payload.channelId),
      }),
    ).rejects.toThrow(/invalid voucher signature/)
  })

  test('rejects missing precompile descriptors with a verification error', async () => {
    const { method } = createServer()
    const payload = await createOpenPayload()
    const { descriptor: _descriptor, ...payloadWithoutDescriptor } = payload

    await expect(
      method.verify({
        credential: {
          challenge: makeChallenge(payload.channelId),
          payload: payloadWithoutDescriptor,
        },
        request: verifyRequest(payload.channelId),
      }),
    ).rejects.toThrow(/descriptor required for TIP-1034 session action/)
  })

  test('rejects uint96 overflow in credential amount parsing', async () => {
    const { method } = createServer()
    const payload = await createOpenPayload()

    await expect(
      method.verify({
        credential: {
          challenge: makeChallenge(payload.channelId),
          payload: { ...payload, cumulativeAmount: (1n << 96n).toString() },
        },
        request: verifyRequest(payload.channelId),
      }),
    ).rejects.toThrow(/outside uint96 bounds/)
  })

  test('rejects settle when no account is available', async () => {
    const { store } = createServer()
    const openPayload = await createOpenPayload()
    await persistPrecompileChannel(store, openPayload)

    const { settle } = await import('./Session.js')
    await expect(
      settle(store, createServerClient([], null), openPayload.channelId),
    ).rejects.toThrow(/no account available/)
  })

  test('rejects settle when sender is not the channel payee or operator', async () => {
    const { store } = createServer()
    const openPayload = await createOpenPayload()
    await persistPrecompileChannel(store, openPayload)

    const { settle } = await import('./Session.js')
    await expect(
      settle(store, createServerClient([], wrongPayer), openPayload.channelId),
    ).rejects.toThrow(/tx sender .* is not the channel payee/)
  })

  test('accepts settle sender matching a nonzero precompile operator', async () => {
    const { store } = createServer()
    const openPayload = await createOpenPayload({
      operator: wrongPayer.address,
    })
    await persistPrecompileChannel(store, openPayload)

    const { settle } = await import('./Session.js')
    const client = createClient({
      account: wrongPayer,
      chain: testChain,
      transport: custom({
        async request(args) {
          if (args.method === 'eth_chainId') return `0x${chainId.toString(16)}`
          throw new Error(`unexpected rpc request: ${args.method}`)
        },
      }),
    })
    await expect(settle(store, client, openPayload.channelId)).rejects.toThrow(
      /eth_getTransactionCount/,
    )
  })

  test('precompile settle fee payer options still enforce payee sender policy', async () => {
    const { store } = createServer()
    const openPayload = await createOpenPayload()
    await persistPrecompileChannel(store, openPayload)

    const { settle } = await import('./Session.js')
    await expect(
      settle(store, createServerClient([], payer), openPayload.channelId, {
        feePayer: wrongPayer,
      }),
    ).rejects.toThrow(/tx sender .* is not the channel payee/)
  })

  test('accepts precompile settle fee token options', async () => {
    const { store } = createServer()
    const openPayload = await createOpenPayload()
    await persistPrecompileChannel(store, openPayload, {
      payee: payer.address,
    })
    const client = createClient({
      account: payer,
      chain: testChain,
      transport: custom({
        async request(args) {
          if (args.method === 'eth_chainId') return `0x${chainId.toString(16)}`
          if (args.method === 'eth_sendTransaction') throw new Error('sent fee-token settle')
          throw new Error(`unexpected rpc request: ${args.method}`)
        },
      }),
    })

    const { settle } = await import('./Session.js')
    await expect(
      settle(store, client, openPayload.channelId, {
        feeToken: token,
      }),
    ).rejects.toThrow(/eth_getTransactionCount/)
  })

  test('accepts settle account override matching the channel payee', async () => {
    const { store } = createServer()
    const openPayload = await createOpenPayload()
    await persistPrecompileChannel(store, openPayload, {
      payee: wrongPayer.address,
    })
    const client = createClient({
      account: payer,
      chain: testChain,
      transport: custom({
        async request(args) {
          if (args.method === 'eth_sendTransaction') throw new Error('sent settle transaction')
          if (args.method === 'eth_chainId') return `0x${chainId.toString(16)}`
          throw new Error(`unexpected rpc request: ${args.method}`)
        },
      }),
    })

    const { settle } = await import('./Session.js')
    await expect(
      settle(store, client, openPayload.channelId, {
        account: wrongPayer,
      }),
    ).rejects.toThrow(/eth_getTransactionCount/)
  })

  test('rejects precompile settle fee-payer policy violations', async () => {
    const { store } = createServer()
    const openPayload = await createOpenPayload()
    await persistPrecompileChannel(store, openPayload, {
      payee: payer.address,
    })

    const { settle } = await import('./Session.js')
    await expect(
      settle(store, createServerClient([], payer), openPayload.channelId, {
        feePayer: wrongPayer,
        feePayerPolicy: { maxGas: 1n },
        feeToken: token,
      }),
    ).rejects.toThrow(/fee-payer policy maxGas exceeded/)
  })

  test('rejects close voucher below local spent', async () => {
    const rawStore = Store.memory()
    const store = channelStore(rawStore)
    const openPayload = await createOpenPayload()
    await persistPrecompileChannel(store, openPayload, {
      payee: payer.address,
      spent: 150n,
    })
    const method = session({
      account: payer,
      amount: '1',
      chainId,
      currency: token,
      decimals: 0,
      recipient: payee,
      store: rawStore,
      unitType: 'request',
      getClient: () => createStateClient(payer),
    })
    const payload = await ClientOps.createClosePayload(
      createSigningClient(),
      payer,
      openPayload.descriptor,
      Types.uint96(100n),
      chainId,
    )

    await expect(
      method.verify({
        credential: {
          challenge: makeChallenge(openPayload.channelId),
          payload,
        },
        request: verifyRequest(openPayload.channelId),
      }),
    ).rejects.toThrow(/close voucher amount must be >= 150 \(spent\)/)
  })

  test('rejects close voucher below on-chain settled', async () => {
    const rawStore = Store.memory()
    const store = channelStore(rawStore)
    const openPayload = await createOpenPayload()
    await persistPrecompileChannel(store, openPayload, {
      payee: payer.address,
    })
    const method = session({
      account: payer,
      amount: '1',
      chainId,
      currency: token,
      decimals: 0,
      recipient: payee,
      store: rawStore,
      unitType: 'request',
      getClient: () =>
        createStateClient(payer, {
          settled: 100n,
          deposit: 1_000n,
          closeRequestedAt: 0,
        }),
    })
    const payload = await ClientOps.createClosePayload(
      createSigningClient(),
      payer,
      openPayload.descriptor,
      Types.uint96(99n),
      chainId,
    )

    await expect(
      method.verify({
        credential: {
          challenge: makeChallenge(openPayload.channelId),
          payload,
        },
        request: verifyRequest(openPayload.channelId),
      }),
    ).rejects.toThrow(/close voucher amount must be >= 100 \(on-chain settled\)/)
  })

  test('rejects close capture exceeding on-chain precompile deposit', async () => {
    const rawStore = Store.memory()
    const store = channelStore(rawStore)
    const openPayload = await createOpenPayload()
    await persistPrecompileChannel(store, openPayload, {
      payee: payer.address,
      spent: 100n,
    })
    const method = session({
      account: payer,
      amount: '1',
      chainId,
      currency: token,
      decimals: 0,
      recipient: payee,
      store: rawStore,
      unitType: 'request',
      getClient: () =>
        createStateClient(payer, {
          settled: 0n,
          deposit: 99n,
          closeRequestedAt: 0,
        }),
    })
    const payload = await ClientOps.createClosePayload(
      createSigningClient(),
      payer,
      openPayload.descriptor,
      Types.uint96(100n),
      chainId,
    )

    await expect(
      method.verify({
        credential: {
          challenge: makeChallenge(openPayload.channelId),
          payload,
        },
        request: verifyRequest(openPayload.channelId),
      }),
    ).rejects.toThrow(/close capture amount exceeds on-chain deposit/)
  })

  test('rejects close for locally finalized and pending precompile channels', async () => {
    const rawStore = Store.memory()
    const store = channelStore(rawStore)
    const openPayload = await createOpenPayload()
    const payload = await ClientOps.createClosePayload(
      createSigningClient(),
      payer,
      openPayload.descriptor,
      Types.uint96(100n),
      chainId,
    )
    const method = session({
      account: payer,
      amount: '1',
      chainId,
      currency: token,
      decimals: 0,
      recipient: payee,
      store: rawStore,
      unitType: 'request',
      getClient: () => createStateClient(payer),
    })

    await persistPrecompileChannel(store, openPayload, {
      finalized: true,
      payee: payer.address,
    })
    await expect(
      method.verify({
        credential: {
          challenge: makeChallenge(openPayload.channelId),
          payload,
        },
        request: verifyRequest(openPayload.channelId),
      }),
    ).rejects.toThrow(/channel is already finalized/)

    await persistPrecompileChannel(store, openPayload, {
      closeRequestedAt: 1n,
      payee: payer.address,
    })
    await expect(
      method.verify({
        credential: {
          challenge: makeChallenge(openPayload.channelId),
          payload,
        },
        request: verifyRequest(openPayload.channelId),
      }),
    ).rejects.toThrow(/channel has a pending close request/)
  })

  test('accepts valid precompile open with voucher and stores state', async () => {
    const rawStore = Store.memory()
    const store = channelStore(rawStore)
    const openPayload = await createOpenPayload({ initialAmount: 100n })
    const method = session({
      amount: '1',
      chainId,
      currency: token,
      decimals: 0,
      recipient: payee,
      store: rawStore,
      unitType: 'request',
      getClient: () =>
        createServerClient([], payer, openPayload.channelId, {
          descriptor: openPayload.descriptor,
          receipt: transactionReceipt([openedLog(openPayload)]),
          state: { settled: 0n, deposit: 1_000n, closeRequestedAt: 0 },
        }),
    })

    const receipt = (await method.verify({
      credential: {
        challenge: makeChallenge(openPayload.channelId),
        payload: openPayload,
      },
      request: verifyRequest(openPayload.channelId),
    })) as SessionReceipt

    const stored = await store.getChannel(openPayload.channelId)
    expect(receipt.acceptedCumulative).toBe('100')
    expect(stored?.backend).toBe('precompile')
    expect(stored?.deposit).toBe(1_000n)
    expect(stored?.highestVoucherAmount).toBe(100n)
    if (!stored || !ChannelStore.isPrecompileState(stored))
      throw new Error('expected precompile state')
    expect(stored.descriptor).toEqual(openPayload.descriptor)
  })

  test('reopening existing precompile channel with higher voucher updates highest voucher only', async () => {
    const rawStore = Store.memory()
    const store = channelStore(rawStore)
    const openPayload = await createOpenPayload({ initialAmount: 100n })
    await persistPrecompileChannel(store, openPayload, {
      highestVoucherAmount: 100n,
      spent: 75n,
      units: 3,
    })
    const reopenPayload = { ...openPayload, cumulativeAmount: '250' }
    reopenPayload.signature = await Voucher.signVoucher(
      createSigningClient(),
      payer,
      { channelId: openPayload.channelId, cumulativeAmount: 250n },
      tip20ChannelEscrow,
      chainId,
    )
    const method = session({
      amount: '1',
      chainId,
      currency: token,
      decimals: 0,
      recipient: payee,
      store: rawStore,
      unitType: 'request',
      getClient: () =>
        createServerClient([], payer, openPayload.channelId, {
          descriptor: openPayload.descriptor,
          receipt: transactionReceipt([openedLog(openPayload)]),
          state: { settled: 0n, deposit: 1_000n, closeRequestedAt: 0 },
        }),
    })

    const receipt = (await method.verify({
      credential: {
        challenge: makeChallenge(openPayload.channelId),
        payload: reopenPayload,
      },
      request: verifyRequest(openPayload.channelId),
    })) as SessionReceipt

    const stored = await store.getChannel(openPayload.channelId)
    expect(receipt.acceptedCumulative).toBe('250')
    expect(receipt.spent).toBe('75')
    expect(receipt.units).toBe(3)
    expect(stored?.highestVoucherAmount).toBe(250n)
    expect(stored?.spent).toBe(75n)
    expect(stored?.units).toBe(3)
  })

  test('reopening existing precompile channel with same voucher preserves accounting', async () => {
    const rawStore = Store.memory()
    const store = channelStore(rawStore)
    const openPayload = await createOpenPayload({ initialAmount: 100n })
    await persistPrecompileChannel(store, openPayload, {
      highestVoucherAmount: 100n,
      spent: 75n,
      units: 3,
    })
    const method = session({
      amount: '1',
      chainId,
      currency: token,
      decimals: 0,
      recipient: payee,
      store: rawStore,
      unitType: 'request',
      getClient: () =>
        createServerClient([], payer, openPayload.channelId, {
          descriptor: openPayload.descriptor,
          receipt: transactionReceipt([openedLog(openPayload)]),
          state: { settled: 0n, deposit: 1_000n, closeRequestedAt: 0 },
        }),
    })

    const receipt = (await method.verify({
      credential: {
        challenge: makeChallenge(openPayload.channelId),
        payload: openPayload,
      },
      request: verifyRequest(openPayload.channelId),
    })) as SessionReceipt

    const stored = await store.getChannel(openPayload.channelId)
    expect(receipt.acceptedCumulative).toBe('100')
    expect(receipt.spent).toBe('75')
    expect(receipt.units).toBe(3)
    expect(stored?.highestVoucherAmount).toBe(100n)
    expect(stored?.spent).toBe(75n)
    expect(stored?.units).toBe(3)
  })

  test('case-variant precompile channelId does not reset open accounting', async () => {
    const rawStore = Store.memory()
    const store = channelStore(rawStore)
    const openPayload = await createOpenPayload({ initialAmount: 100n })
    await persistPrecompileChannel(store, openPayload, { spent: 75n, units: 3 })
    const mixedCaseChannelId = openPayload.channelId.replace(/[a-f]/g, (char) =>
      char.toUpperCase(),
    ) as Hex
    const method = session({
      amount: '1',
      chainId,
      currency: token,
      decimals: 0,
      recipient: payee,
      store: rawStore,
      unitType: 'request',
      getClient: () =>
        createServerClient([], payer, openPayload.channelId, {
          descriptor: openPayload.descriptor,
          receipt: transactionReceipt([openedLog(openPayload)]),
          state: { settled: 0n, deposit: 1_000n, closeRequestedAt: 0 },
        }),
    })

    const receipt = (await method.verify({
      credential: {
        challenge: makeChallenge(mixedCaseChannelId),
        payload: { ...openPayload, channelId: mixedCaseChannelId },
      },
      request: verifyRequest(mixedCaseChannelId),
    })) as SessionReceipt

    const stored = await store.getChannel(openPayload.channelId)
    expect(receipt.spent).toBe('75')
    expect(receipt.units).toBe(3)
    expect(stored?.spent).toBe(75n)
    expect(stored?.units).toBe(3)
  })

  test('uses payer as precompile voucher signer when authorized signer is zero', async () => {
    const rawStore = Store.memory()
    const store = channelStore(rawStore)
    const openPayload = await createOpenPayload({
      authorizedSigner: zeroAddress,
      initialAmount: 100n,
    })
    expect(openPayload.descriptor.authorizedSigner).toBe(zeroAddress)
    const method = session({
      amount: '1',
      chainId,
      currency: token,
      decimals: 0,
      recipient: payee,
      store: rawStore,
      unitType: 'request',
      getClient: () =>
        createServerClient([], payer, openPayload.channelId, {
          descriptor: openPayload.descriptor,
          receipt: transactionReceipt([openedLog(openPayload)]),
          state: { settled: 0n, deposit: 1_000n, closeRequestedAt: 0 },
        }),
    })

    const receipt = (await method.verify({
      credential: {
        challenge: makeChallenge(openPayload.channelId),
        payload: openPayload,
      },
      request: verifyRequest(openPayload.channelId),
    })) as SessionReceipt

    const stored = await store.getChannel(openPayload.channelId)
    expect(receipt.acceptedCumulative).toBe('100')
    expect(stored?.authorizedSigner).toBe(payer.address)
  })

  test('accepts precompile top-up and preserves spent accounting', async () => {
    const rawStore = Store.memory()
    const store = channelStore(rawStore)
    const openPayload = await createOpenPayload({ initialAmount: 100n })
    await persistPrecompileChannel(store, openPayload, {
      deposit: 1_000n,
      spent: 125n,
      units: 4,
    })
    const topUpPayload = await createTopUpPayload(openPayload.descriptor, 500n)
    const method = session({
      amount: '1',
      chainId,
      currency: token,
      decimals: 0,
      recipient: payee,
      store: rawStore,
      unitType: 'request',
      getClient: () =>
        createServerClient([], payer, topUpPayload.channelId, {
          receipt: transactionReceipt([topUpLog(topUpPayload, 1_500n)]),
          state: { settled: 0n, deposit: 1_500n, closeRequestedAt: 0 },
        }),
    })

    const receipt = (await method.verify({
      credential: {
        challenge: makeChallenge(openPayload.channelId),
        payload: topUpPayload,
      },
      request: verifyRequest(openPayload.channelId),
    })) as SessionReceipt

    const stored = await store.getChannel(openPayload.channelId)
    expect(receipt.spent).toBe('125')
    expect(receipt.units).toBe(4)
    expect(stored?.deposit).toBe(1_500n)
    expect(stored?.spent).toBe(125n)
    expect(stored?.units).toBe(4)
  })

  test('rejects precompile top-up when on-chain state has pending close', async () => {
    const rawStore = Store.memory()
    const store = channelStore(rawStore)
    const openPayload = await createOpenPayload({ initialAmount: 100n })
    await persistPrecompileChannel(store, openPayload, { deposit: 1_000n })
    const topUpPayload = await createTopUpPayload(openPayload.descriptor, 500n)
    const method = session({
      amount: '1',
      chainId,
      currency: token,
      decimals: 0,
      recipient: payee,
      store: rawStore,
      unitType: 'request',
      getClient: () =>
        createServerClient([], payer, topUpPayload.channelId, {
          receipt: transactionReceipt([topUpLog(topUpPayload, 1_500n)]),
          state: { settled: 0n, deposit: 1_500n, closeRequestedAt: 1 },
        }),
    })

    await expect(
      method.verify({
        credential: {
          challenge: makeChallenge(openPayload.channelId),
          payload: topUpPayload,
        },
        request: verifyRequest(openPayload.channelId),
      }),
    ).rejects.toThrow(/pending close request/)
  })

  test('rejects precompile top-up on unknown channel', async () => {
    const { method } = createServer()
    const openPayload = await createOpenPayload({ initialAmount: 100n })
    const topUpPayload = await createTopUpPayload(openPayload.descriptor, 500n)

    await expect(
      method.verify({
        credential: {
          challenge: makeChallenge(openPayload.channelId),
          payload: topUpPayload,
        },
        request: verifyRequest(openPayload.channelId),
      }),
    ).rejects.toThrow(/channel not found/)
  })

  test('rejects precompile top-up descriptor mismatches', async () => {
    const { method, store } = createServer()
    const openPayload = await createOpenPayload({ initialAmount: 100n })
    await persistPrecompileChannel(store, openPayload)
    const badDescriptor = { ...openPayload.descriptor, payee: wrongTarget }
    const topUpPayload = await createTopUpPayload(badDescriptor, 500n)

    await expect(
      method.verify({
        credential: {
          challenge: makeChallenge(openPayload.channelId),
          payload: { ...topUpPayload, channelId: openPayload.channelId },
        },
        request: verifyRequest(openPayload.channelId),
      }),
    ).rejects.toThrow(/descriptor does not match/)
  })

  test('accepts increasing precompile voucher and stores accounting state', async () => {
    const { method, store } = createServer({ channelStateTtl: Number.MAX_SAFE_INTEGER })
    const openPayload = await createOpenPayload({ initialAmount: 100n })
    await persistPrecompileChannel(store, openPayload, {
      highestVoucherAmount: 100n,
      spent: 100n,
      units: 1,
    })
    const voucher = await ClientOps.createVoucherPayload(
      createSigningClient(),
      payer,
      openPayload.descriptor,
      Types.uint96(250n),
      chainId,
    )

    const receipt = (await method.verify({
      credential: {
        challenge: makeChallenge(openPayload.channelId),
        payload: voucher,
      },
      request: verifyRequest(openPayload.channelId),
    })) as SessionReceipt

    const stored = await store.getChannel(openPayload.channelId)
    expect(receipt.acceptedCumulative).toBe('250')
    expect(receipt.spent).toBe('100')
    expect(receipt.units).toBe(1)
    expect(stored?.highestVoucherAmount).toBe(250n)
    expect(stored?.spent).toBe(100n)
    expect(stored?.units).toBe(1)
  })

  test('accepts exact precompile voucher replay idempotently', async () => {
    const { method, store } = createServer({ channelStateTtl: Number.MAX_SAFE_INTEGER })
    const openPayload = await createOpenPayload({ initialAmount: 100n })
    const voucher = await ClientOps.createVoucherPayload(
      createSigningClient(),
      payer,
      openPayload.descriptor,
      Types.uint96(250n),
      chainId,
    )
    if (voucher.action !== 'voucher') throw new Error('expected voucher payload')
    await persistPrecompileChannel(store, openPayload, {
      highestVoucherAmount: 250n,
      highestVoucher: {
        channelId: openPayload.channelId,
        cumulativeAmount: 250n,
        signature: voucher.signature,
      },
      spent: 250n,
      units: 2,
    })

    const receipt = (await method.verify({
      credential: {
        challenge: makeChallenge(openPayload.channelId),
        payload: voucher,
      },
      request: verifyRequest(openPayload.channelId),
    })) as SessionReceipt

    const stored = await store.getChannel(openPayload.channelId)
    expect(receipt.acceptedCumulative).toBe('250')
    expect(receipt.spent).toBe('250')
    expect(receipt.units).toBe(2)
    expect(stored?.highestVoucherAmount).toBe(250n)
    expect(stored?.units).toBe(2)
  })

  test('rejects lower precompile voucher replay', async () => {
    const { method, store } = createServer({ channelStateTtl: Number.MAX_SAFE_INTEGER })
    const openPayload = await createOpenPayload({ initialAmount: 100n })
    await persistPrecompileChannel(store, openPayload, {
      highestVoucherAmount: 500n,
      spent: 500n,
      units: 5,
    })
    const voucher = await ClientOps.createVoucherPayload(
      createSigningClient(),
      payer,
      openPayload.descriptor,
      Types.uint96(250n),
      chainId,
    )

    await expect(
      method.verify({
        credential: {
          challenge: makeChallenge(openPayload.channelId),
          payload: voucher,
        },
        request: verifyRequest(openPayload.channelId),
      }),
    ).rejects.toThrow(
      /strictly greater than highest accepted voucher|non-increasing voucher|voucher replay/,
    )
  })

  test('rejects precompile voucher below minVoucherDelta', async () => {
    const { method, store } = createServer({
      channelStateTtl: Number.MAX_SAFE_INTEGER,
      minVoucherDelta: '200',
    })
    const openPayload = await createOpenPayload({ initialAmount: 100n })
    await persistPrecompileChannel(store, openPayload, { highestVoucherAmount: 100n })
    const voucher = await ClientOps.createVoucherPayload(
      createSigningClient(),
      payer,
      openPayload.descriptor,
      Types.uint96(250n),
      chainId,
    )

    await expect(
      method.verify({
        credential: {
          challenge: makeChallenge(openPayload.channelId),
          payload: voucher,
        },
        request: verifyRequest(openPayload.channelId),
      }),
    ).rejects.toThrow(/voucher delta 150 below minimum 200/)
  })

  test('accepts idempotent precompile voucher replay after on-chain settlement catches up', async () => {
    const rawStore = Store.memory()
    const store = channelStore(rawStore)
    const openPayload = await createOpenPayload({ initialAmount: 100n })
    await persistPrecompileChannel(store, openPayload, {
      highestVoucherAmount: 500n,
      settledOnChain: 500n,
      spent: 500n,
      units: 10,
    })
    const voucher = await ClientOps.createVoucherPayload(
      createSigningClient(),
      payer,
      openPayload.descriptor,
      Types.uint96(500n),
      chainId,
    )
    const method = session({
      amount: '1',
      chainId,
      currency: token,
      decimals: 0,
      recipient: payee,
      store: rawStore,
      unitType: 'request',
      getClient: () =>
        createStateClient(payer, { settled: 500n, deposit: 1_000n, closeRequestedAt: 0 }),
    })

    const receipt = (await method.verify({
      credential: {
        challenge: makeChallenge(openPayload.channelId),
        payload: voucher,
      },
      request: verifyRequest(openPayload.channelId),
    })) as SessionReceipt

    expect(receipt.acceptedCumulative).toBe('500')
    expect(receipt.spent).toBe('500')
    expect(receipt.units).toBe(10)
  })

  test('rejects stale or hijacked precompile voucher signatures', async () => {
    const { method, store } = createServer({ channelStateTtl: Number.MAX_SAFE_INTEGER })
    const openPayload = await createOpenPayload({ initialAmount: 100n })
    await persistPrecompileChannel(store, openPayload, { highestVoucherAmount: 100n })
    const signature = await Voucher.signVoucher(
      createSigningClient(wrongPayer),
      wrongPayer,
      { channelId: openPayload.channelId, cumulativeAmount: 250n },
      tip20ChannelEscrow,
      chainId,
    )

    await expect(
      method.verify({
        credential: {
          challenge: makeChallenge(openPayload.channelId),
          payload: {
            action: 'voucher',
            channelId: openPayload.channelId,
            cumulativeAmount: '250',
            descriptor: openPayload.descriptor,
            signature,
          },
        },
        request: verifyRequest(openPayload.channelId),
      }),
    ).rejects.toThrow(/invalid voucher signature/)
  })

  test('rejects precompile voucher exceeding deposit', async () => {
    const { method, store } = createServer({ channelStateTtl: Number.MAX_SAFE_INTEGER })
    const openPayload = await createOpenPayload({ initialAmount: 100n })
    await persistPrecompileChannel(store, openPayload, { deposit: 300n })
    const voucher = await ClientOps.createVoucherPayload(
      createSigningClient(),
      payer,
      openPayload.descriptor,
      Types.uint96(350n),
      chainId,
    )

    await expect(
      method.verify({
        credential: {
          challenge: makeChallenge(openPayload.channelId),
          payload: voucher,
        },
        request: verifyRequest(openPayload.channelId),
      }),
    ).rejects.toThrow(/exceeds.*deposit|insufficient channel deposit/)
  })

  test('rejects precompile voucher when on-chain state has pending close', async () => {
    const rawStore = Store.memory()
    const store = channelStore(rawStore)
    const openPayload = await createOpenPayload({ initialAmount: 100n })
    await persistPrecompileChannel(store, openPayload, { closeRequestedAt: 0n })
    const voucher = await ClientOps.createVoucherPayload(
      createSigningClient(),
      payer,
      openPayload.descriptor,
      Types.uint96(250n),
      chainId,
    )
    const method = session({
      amount: '1',
      chainId,
      channelStateTtl: 0,
      currency: token,
      decimals: 0,
      recipient: payee,
      store: rawStore,
      unitType: 'request',
      getClient: () =>
        createStateClient(payer, { settled: 0n, deposit: 1_000n, closeRequestedAt: 1 }),
    })

    await expect(
      method.verify({
        credential: {
          challenge: makeChallenge(openPayload.channelId),
          payload: voucher,
        },
        request: verifyRequest(openPayload.channelId),
      }),
    ).rejects.toThrow(/pending close request/)
  })

  test('rejects precompile voucher when on-chain deposit is zero', async () => {
    const rawStore = Store.memory()
    const store = channelStore(rawStore)
    const openPayload = await createOpenPayload({ initialAmount: 100n })
    await persistPrecompileChannel(store, openPayload, { deposit: 1_000n })
    const voucher = await ClientOps.createVoucherPayload(
      createSigningClient(),
      payer,
      openPayload.descriptor,
      Types.uint96(250n),
      chainId,
    )
    const method = session({
      amount: '1',
      chainId,
      channelStateTtl: 0,
      currency: token,
      decimals: 0,
      recipient: payee,
      store: rawStore,
      unitType: 'request',
      getClient: () => createStateClient(payer, { settled: 0n, deposit: 0n, closeRequestedAt: 0 }),
    })

    await expect(
      method.verify({
        credential: {
          challenge: makeChallenge(openPayload.channelId),
          payload: voucher,
        },
        request: verifyRequest(openPayload.channelId),
      }),
    ).rejects.toThrow(/deposit is zero|channel deposit is zero|not found/)
  })

  test('rejects precompile voucher on unknown channel', async () => {
    const { method } = createServer({ channelStateTtl: Number.MAX_SAFE_INTEGER })
    const openPayload = await createOpenPayload({ initialAmount: 100n })
    const voucher = await ClientOps.createVoucherPayload(
      createSigningClient(),
      payer,
      openPayload.descriptor,
      Types.uint96(250n),
      chainId,
    )

    await expect(
      method.verify({
        credential: {
          challenge: makeChallenge(openPayload.channelId),
          payload: voucher,
        },
        request: verifyRequest(openPayload.channelId),
      }),
    ).rejects.toThrow(/unknown channel|not found/)
  })

  describe('respond', () => {
    function respond(action: SessionCredentialPayload['action'], input: Request) {
      const { method } = createServer()
      return method.respond!({
        credential: {
          challenge: makeChallenge(`0x${'01'.repeat(32)}` as Hex),
          payload: { action },
        },
        input,
      } as never)
    }

    test('returns 204 for close management requests', () => {
      const result = respond('close', new Request('http://localhost', { method: 'GET' }))
      expect(result).toBeInstanceOf(Response)
      expect((result as Response).status).toBe(204)
    })

    test('returns 204 for top-up management requests', () => {
      const result = respond('topUp', new Request('http://localhost', { method: 'POST' }))
      expect(result).toBeInstanceOf(Response)
      expect((result as Response).status).toBe(204)
    })

    test('returns 204 for open POST management requests', () => {
      const result = respond('open', new Request('http://localhost', { method: 'POST' }))
      expect(result).toBeInstanceOf(Response)
      expect((result as Response).status).toBe(204)
    })

    test('returns 204 for voucher POST management requests', () => {
      const result = respond('voucher', new Request('http://localhost', { method: 'POST' }))
      expect(result).toBeInstanceOf(Response)
      expect((result as Response).status).toBe(204)
    })

    test('lets open and voucher GET content requests through', () => {
      expect(respond('open', new Request('http://localhost', { method: 'GET' }))).toBeUndefined()
      expect(respond('voucher', new Request('http://localhost', { method: 'GET' }))).toBeUndefined()
    })

    test('lets open and voucher POST content requests with bodies through', () => {
      expect(
        respond(
          'open',
          new Request('http://localhost', { method: 'POST', headers: { 'content-length': '1' } }),
        ),
      ).toBeUndefined()
      expect(
        respond(
          'voucher',
          new Request('http://localhost', {
            method: 'POST',
            headers: { 'transfer-encoding': 'chunked' },
          }),
        ),
      ).toBeUndefined()
    })

    test('returns 204 for voucher POST with content-length zero', () => {
      const result = respond(
        'voucher',
        new Request('http://localhost', { method: 'POST', headers: { 'content-length': '0' } }),
      )
      expect(result).toBeInstanceOf(Response)
      expect((result as Response).status).toBe(204)
    })
  })

  describe('default HTTP auto-billing', () => {
    function createRoute(rawStore: Store.AtomicStore) {
      return Mppx_server.create({
        methods: [
          tempo_server.session({
            amount: '1',
            chainId,
            currency: token,
            decimals: 0,
            recipient: payee,
            store: rawStore,
            unitType: 'request',
            getClient: () => createStateClient(payer),
          }),
        ],
        realm: 'api.example.com',
        secretKey: 'secret',
      }).session({ amount: '1', decimals: 0, unitType: 'request' })
    }

    test('GET content flow charges once and rejects same-voucher replay', async () => {
      const rawStore = Store.memory()
      const store = channelStore(rawStore)
      const openPayload = await createOpenPayload({ initialAmount: 1n })
      await persistPrecompileChannel(store, openPayload, {
        highestVoucherAmount: 1n,
        spent: 0n,
        units: 0,
      })
      const route = createRoute(rawStore)
      const voucher = await ClientOps.createVoucherPayload(
        createSigningClient(),
        payer,
        openPayload.descriptor,
        Types.uint96(1n),
        chainId,
      )

      const serve = async (request: Request) => {
        const result = await route(request)
        if (result.status === 402) return result.challenge
        return result.withReceipt(new Response('paid-content'))
      }

      const first = await route(new Request('https://api.example.com/resource'))
      expect(first.status).toBe(402)
      if (first.status !== 402) throw new Error('expected challenge')

      const paid = await serve(
        new Request('https://api.example.com/resource', {
          headers: {
            Authorization: Credential.serialize({
              challenge: Challenge.fromResponse(first.challenge),
              payload: voucher,
            }),
          },
        }),
      )
      expect(paid.status).toBe(200)
      expect(await paid.text()).toBe('paid-content')
      const receipt = deserializeSessionReceipt(paid.headers.get('Payment-Receipt') as string)
      expect(receipt.acceptedCumulative).toBe('1')
      expect(receipt.spent).toBe('1')
      expect(receipt.units).toBe(1)

      const replayChallenge = await route(new Request('https://api.example.com/resource'))
      expect(replayChallenge.status).toBe(402)
      if (replayChallenge.status !== 402) throw new Error('expected challenge')

      const replay = await serve(
        new Request('https://api.example.com/resource', {
          headers: {
            Authorization: Credential.serialize({
              challenge: Challenge.fromResponse(replayChallenge.challenge),
              payload: voucher,
            }),
          },
        }),
      )
      expect(replay.status).toBe(402)
      expect(replay.headers.get('Payment-Receipt')).toBeNull()
    })

    test('POST content flow charges once and rejects same-voucher replay', async () => {
      const rawStore = Store.memory()
      const store = channelStore(rawStore)
      const openPayload = await createOpenPayload({ initialAmount: 1n })
      await persistPrecompileChannel(store, openPayload)
      const route = createRoute(rawStore)
      const voucher = await ClientOps.createVoucherPayload(
        createSigningClient(),
        payer,
        openPayload.descriptor,
        Types.uint96(1n),
        chainId,
      )
      const makeRequest = (authorization?: string) =>
        new Request('https://api.example.com/resource', {
          method: 'POST',
          body: '{}',
          headers: {
            'content-length': '2',
            'content-type': 'application/json',
            ...(authorization ? { Authorization: authorization } : {}),
          },
        })

      const first = await route(makeRequest())
      expect(first.status).toBe(402)
      if (first.status !== 402) throw new Error('expected challenge')

      const result = await route(
        makeRequest(
          Credential.serialize({
            challenge: Challenge.fromResponse(first.challenge),
            payload: voucher,
          }),
        ),
      )
      expect(result.status).toBe(200)
      if (result.status !== 200) throw new Error('expected paid response')
      const paid = result.withReceipt(new Response('paid-content'))
      const receipt = deserializeSessionReceipt(paid.headers.get('Payment-Receipt') as string)
      expect(receipt.spent).toBe('1')
      expect(receipt.units).toBe(1)

      const replayChallenge = await route(makeRequest())
      expect(replayChallenge.status).toBe(402)
      if (replayChallenge.status !== 402) throw new Error('expected challenge')
      const replay = await route(
        makeRequest(
          Credential.serialize({
            challenge: Challenge.fromResponse(replayChallenge.challenge),
            payload: voucher,
          }),
        ),
      )
      expect(replay.status).toBe(402)
      if (replay.status !== 402) throw new Error('expected challenge')
      expect(replay.challenge.headers.get('Payment-Receipt')).toBeNull()
    })

    test('verification errors do not include Payment-Receipt', async () => {
      const rawStore = Store.memory()
      const store = channelStore(rawStore)
      const openPayload = await createOpenPayload({ initialAmount: 100n })
      await persistPrecompileChannel(store, openPayload)
      const route = createRoute(rawStore)
      const first = await route(new Request('https://api.example.com/resource'))
      expect(first.status).toBe(402)
      if (first.status !== 402) throw new Error('expected challenge')

      const failed = await route(
        new Request('https://api.example.com/resource', {
          headers: {
            Authorization: Credential.serialize({
              challenge: Challenge.fromResponse(first.challenge),
              payload: {
                action: 'voucher',
                channelId: openPayload.channelId,
                cumulativeAmount: '100',
                descriptor: openPayload.descriptor,
                signature: (await createOpenPayload({ account: wrongPayer })).signature,
              },
            }),
          },
        }),
      )

      expect(failed.status).toBe(402)
      if (failed.status !== 402) throw new Error('expected challenge')
      expect(failed.challenge.headers.get('Payment-Receipt')).toBeNull()
    })
  })

  describe('same-route bootstrap', () => {
    function createBootstrapRoute(parameters: {
      rawStore: Store.AtomicStore
      recipient?: Address | undefined
      resolveChannelId?: ResolveSessionChannelId | undefined
    }) {
      return Mppx_server.create({
        methods: [
          tempo_server.session({
            amount: '1',
            bootstrap: true,
            chainId,
            currency: token,
            decimals: 0,
            getClient: () => createStateClient(payer),
            recipient: parameters.recipient ?? payee,
            resolveChannelId: parameters.resolveChannelId,
            store: parameters.rawStore,
            unitType: 'request',
          }),
        ],
        realm: 'api.example.com',
        secretKey: 'secret',
      }).session({ amount: '1', decimals: 0, unitType: 'request' })
    }

    async function createBootstrapCredential(response: Response) {
      const challenge = Challenge.fromResponse(response)
      const method = clientCharge({
        account: payer,
        getClient: () => createSigningClient(),
      })
      return method.createCredential({ challenge: challenge as never, context: {} })
    }

    async function bootstrapResponse(
      route: ReturnType<typeof createBootstrapRoute>,
      authorization?: string,
    ) {
      const result = await route(
        new Request('https://api.example.com/resource', {
          method: 'HEAD',
          ...(authorization ? { headers: { Authorization: authorization } } : {}),
        }),
      )
      if (result.status === 402) return result.challenge
      return result.withReceipt(new Response(null, { status: 500 }))
    }

    test('HEAD without auth emits a zero-amount tempo charge challenge', async () => {
      const route = createBootstrapRoute({ rawStore: Store.memory() })

      const response = await bootstrapResponse(route)
      const challenge = Challenge.fromResponse(response)

      expect(response.status).toBe(402)
      expect(challenge.method).toBe('tempo')
      expect(challenge.intent).toBe('charge')
      expect(challenge.request.amount).toBe('0')
    })

    test('valid proof resolves channel by source and returns snapshot headers', async () => {
      const rawStore = Store.memory()
      const store = channelStore(rawStore)
      const openPayload = await createOpenPayload({ initialAmount: 1n })
      await persistPrecompileChannel(store, openPayload, {
        highestVoucherAmount: 5n,
        spent: 3n,
        units: 3,
      })
      const resolveChannelId = vi.fn(({ source }) => {
        expect(source).toContain(payer.address)
        return openPayload.channelId
      })
      const route = createBootstrapRoute({ rawStore, resolveChannelId })
      const challengeResponse = await bootstrapResponse(route)
      const authorization = await createBootstrapCredential(challengeResponse)

      const response = await bootstrapResponse(route, authorization)

      expect(response.status).toBe(204)
      expect(resolveChannelId).toHaveBeenCalledOnce()
      expect(response.headers.get(Constants.Headers.paymentSession)).toBe(openPayload.channelId)
      const snapshot = session.deserializeSnapshot(
        response.headers.get(Constants.Headers.paymentSessionSnapshot)!,
      )
      expect(snapshot).toMatchObject({
        channelId: openPayload.channelId,
        acceptedCumulative: '5',
        requiredCumulative: '3',
        spent: '3',
      })
    })

    test('valid proof with no resolved channel returns empty 204', async () => {
      const rawStore = Store.memory()
      const route = createBootstrapRoute({
        rawStore,
        resolveChannelId: () => undefined,
      })
      const authorization = await createBootstrapCredential(await bootstrapResponse(route))

      const response = await bootstrapResponse(route, authorization)

      expect(response.status).toBe(204)
      expect(response.headers.get(Constants.Headers.paymentSession)).toBeNull()
      expect(response.headers.get(Constants.Headers.paymentSessionSnapshot)).toBeNull()
    })

    test('valid proof does not return snapshots for channels with different payment fields', async () => {
      const rawStore = Store.memory()
      const store = channelStore(rawStore)
      const openPayload = await createOpenPayload({ initialAmount: 1n })
      await persistPrecompileChannel(store, openPayload)
      const route = createBootstrapRoute({
        rawStore,
        recipient: '0x0000000000000000000000000000000000000004',
        resolveChannelId: () => openPayload.channelId,
      })
      const authorization = await createBootstrapCredential(await bootstrapResponse(route))

      const response = await bootstrapResponse(route, authorization)

      expect(response.status).toBe(204)
      expect(response.headers.get(Constants.Headers.paymentSession)).toBeNull()
      expect(response.headers.get(Constants.Headers.paymentSessionSnapshot)).toBeNull()
    })

    test('replayed proof is rejected before channel resolution', async () => {
      const rawStore = Store.memory()
      const resolveChannelId = vi.fn(() => undefined)
      const route = createBootstrapRoute({ rawStore, resolveChannelId })
      const authorization = await createBootstrapCredential(await bootstrapResponse(route))

      expect((await bootstrapResponse(route, authorization)).status).toBe(204)
      const replay = await bootstrapResponse(route, authorization)

      expect(replay.status).toBe(402)
      expect(resolveChannelId).toHaveBeenCalledOnce()
    })
  })

  describe('SSE parity', () => {
    function createManagedSseFetch(
      options: { amount?: string; maxDeposit?: bigint; unitType?: 'request' | 'token' } = {},
    ) {
      const rawStore = Store.memory()
      let currentPayload: SessionCredentialPayload | undefined
      let voucherPosts = 0
      const amount = options.amount ?? '1'
      const maxDeposit = options.maxDeposit ?? 3n
      const unitType = options.unitType ?? 'token'
      const route = Mppx_server.create({
        methods: [
          tempo_server.session({
            amount,
            chainId,
            currency: token,
            decimals: 0,
            recipient: payer.address,
            sse: true,
            store: rawStore,
            unitType,
            getClient: () => {
              const payload = currentPayload
              if (payload?.action === 'open') {
                return createServerClient([], payer, payload.channelId, {
                  descriptor: payload.descriptor,
                  receipt: transactionReceipt([openedLog(payload, maxDeposit)]),
                  state: { settled: 0n, deposit: maxDeposit, closeRequestedAt: 0 },
                })
              }
              if (payload?.action === 'close') {
                return createServerClient([], payer, payload.channelId, {
                  receipt: transactionReceipt([
                    closedLog(payload.channelId, BigInt(payload.cumulativeAmount), 0n),
                  ]),
                  state: { settled: 0n, deposit: maxDeposit, closeRequestedAt: 0 },
                })
              }
              return createStateClient(payer, {
                settled: 0n,
                deposit: maxDeposit,
                closeRequestedAt: 0,
              })
            },
          }),
        ],
        realm: 'api.example.com',
        secretKey: 'secret',
      }).session({ amount, decimals: 0, suggestedDeposit: maxDeposit.toString(), unitType })

      const fetch = async (input: RequestInfo | URL, init?: RequestInit) => {
        const request = new Request(input, init)
        currentPayload = undefined
        if (request.headers.has('Authorization')) {
          try {
            currentPayload = Credential.fromRequest<SessionCredentialPayload>(request).payload
            if (currentPayload.action === 'voucher') voucherPosts++
          } catch {}
        }

        const result = await route(request)
        if (result.status === 402) return result.challenge
        if (currentPayload?.action === 'voucher') return new Response(null, { status: 200 })

        if (request.headers.get('Accept')?.includes('text/event-stream')) {
          if (unitType === 'request') {
            const encoder = new TextEncoder()
            return result.withReceipt(
              new Response(
                new ReadableStream({
                  start(controller) {
                    controller.enqueue(encoder.encode('event: message\ndata: chunk-1\n\n'))
                    controller.enqueue(encoder.encode('event: message\ndata: chunk-2\n\n'))
                    controller.enqueue(encoder.encode('event: message\ndata: chunk-3\n\n'))
                    controller.close()
                  },
                }),
                { headers: { 'Content-Type': 'text/event-stream; charset=utf-8' } },
              ),
            )
          }

          return result.withReceipt(async function* (stream) {
            await stream.charge()
            yield 'chunk-1'
            await stream.charge()
            yield 'chunk-2'
            await stream.charge()
            yield 'chunk-3'
          })
        }

        return result.withReceipt(new Response('ok'))
      }

      return {
        fetch,
        rawStore,
        get voucherPosts() {
          return voucherPosts
        },
      }
    }

    test('open -> stream -> need-voucher -> resume -> close', async () => {
      const harness = createManagedSseFetch({ maxDeposit: 3n })
      const manager = precompileSessionManager({
        account: payer,
        client: createSigningClient(),
        decimals: 0,
        fetch: harness.fetch,
        maxDeposit: '3',
      })

      const chunks: string[] = []
      const stream = await manager.sse('https://api.example.com/stream')
      for await (const chunk of stream) chunks.push(chunk)

      expect(chunks).toEqual(['chunk-1', 'chunk-2', 'chunk-3'])
      expect(harness.voucherPosts).toBeGreaterThan(0)

      const closeReceipt = await manager.close()
      expect(closeReceipt?.status).toBe('success')
      expect(closeReceipt?.spent).toBe('3')

      const channelId = manager.channelId
      expect(channelId).toBeTruthy()
      const persisted = await channelStore(harness.rawStore).getChannel(channelId!)
      expect(persisted?.finalized).toBe(true)
    })

    test('unitType=request auto-metered SSE responses charge once across the stream', async () => {
      const harness = createManagedSseFetch({ maxDeposit: 1n, unitType: 'request' })
      const manager = precompileSessionManager({
        account: payer,
        client: createSigningClient(),
        decimals: 0,
        fetch: harness.fetch,
        maxDeposit: '1',
      })

      const chunks: string[] = []
      const stream = await manager.sse('https://api.example.com/stream')
      for await (const chunk of stream) chunks.push(chunk)

      expect(chunks).toEqual(['chunk-1', 'chunk-2', 'chunk-3'])
      expect(harness.voucherPosts).toBe(0)

      const closeReceipt = await manager.close()
      expect(closeReceipt?.status).toBe('success')
      expect(closeReceipt?.spent).toBe('1')
    })
  })

  describe('WebSocket parity', () => {
    async function createManagedWsHarness(options: { maxDeposit?: bigint } = {}) {
      const rawStore = Store.memory()
      let currentPayload: SessionCredentialPayload | undefined
      let voucherPosts = 0
      const maxDeposit = options.maxDeposit ?? 3n
      const routeHandler = Mppx_server.create({
        methods: [
          tempo_server.session({
            amount: '1',
            chainId,
            currency: token,
            decimals: 0,
            recipient: payer.address,
            store: rawStore,
            unitType: 'token',
            getClient: () => {
              const payload = currentPayload
              if (payload?.action === 'open') {
                return createServerClient([], payer, payload.channelId, {
                  descriptor: payload.descriptor,
                  receipt: transactionReceipt([openedLog(payload, maxDeposit)]),
                  state: { settled: 0n, deposit: maxDeposit, closeRequestedAt: 0 },
                })
              }
              if (payload?.action === 'close') {
                return createServerClient([], payer, payload.channelId, {
                  receipt: transactionReceipt([
                    closedLog(payload.channelId, BigInt(payload.cumulativeAmount), 0n),
                  ]),
                  state: { settled: 0n, deposit: maxDeposit, closeRequestedAt: 0 },
                })
              }
              return createStateClient(payer, {
                settled: 0n,
                deposit: maxDeposit,
                closeRequestedAt: 0,
              })
            },
          }),
        ],
        realm: 'api.example.com',
        secretKey: 'secret',
      }).session({ amount: '1', decimals: 0, suggestedDeposit: maxDeposit.toString() })

      const route = async (request: Request) => {
        currentPayload = undefined
        if (request.headers.has('Authorization')) {
          try {
            currentPayload = Credential.fromRequest<SessionCredentialPayload>(request).payload
            if (currentPayload.action === 'voucher') voucherPosts++
          } catch {}
        }
        return routeHandler(request)
      }

      const httpHandler = NodeRequest.toNodeListener(async (request) => {
        const result = await route(request)
        if (result.status === 402) return result.challenge
        return result.withReceipt(new Response('ok'))
      })

      const nodeServer = node_http.createServer(httpHandler)
      const wsServer = new WebSocketServer({ noServer: true })

      await new Promise<void>((resolve) => nodeServer.listen(0, resolve))
      const { port } = nodeServer.address() as { port: number }
      const server = Http.wrapServer(nodeServer, {
        port,
        url: `http://localhost:${port}`,
      })

      nodeServer.on('upgrade', (req, socket, head) => {
        if (req.url !== '/ws') {
          socket.destroy()
          return
        }
        wsServer.handleUpgrade(req, socket, head, (websocket) => {
          wsServer.emit('connection', websocket, req)
        })
      })

      return {
        rawStore,
        route,
        server,
        wsServer,
        get port() {
          return port
        },
        get voucherPosts() {
          return voucherPosts
        },
        close() {
          wsServer.close()
          server.close()
        },
      }
    }

    test('open -> stream -> need-voucher -> resume -> close', async () => {
      const harness = await createManagedWsHarness({ maxDeposit: 3n })
      harness.wsServer.on('connection', (socket: import('ws').WebSocket) => {
        void TempoWs.serve({
          socket,
          store: harness.rawStore,
          url: `${harness.server.url}/ws`,
          route: harness.route,
          generate: async function* (stream: TempoWs.SessionController) {
            await stream.charge()
            yield 'chunk-1'
            await stream.charge()
            yield 'chunk-2'
            await stream.charge()
            yield 'chunk-3'
          },
        })
      })

      try {
        const manager = precompileSessionManager({
          account: payer,
          client: createSigningClient(),
          decimals: 0,
          fetch: globalThis.fetch,
          maxDeposit: '3',
          webSocket: WebSocket as never,
        })

        const ws = await manager.ws(`ws://localhost:${harness.port}/ws`)
        const chunks: string[] = []

        await new Promise<void>((resolve, reject) => {
          ws.addEventListener('message', (event) => {
            if (typeof event.data !== 'string') return
            chunks.push(event.data)
          })
          ws.addEventListener('close', () => resolve(), { once: true })
          ws.addEventListener('error', () => reject(new Error('websocket stream failed')), {
            once: true,
          })
        })

        expect(chunks).toEqual(['chunk-1', 'chunk-2', 'chunk-3'])
        expect(harness.voucherPosts).toBeGreaterThan(0)

        const closeReceipt = await manager.close()
        expect(closeReceipt?.status).toBe('success')
        expect(closeReceipt?.spent).toBe('3')

        const channelId = manager.channelId
        expect(channelId).toBeTruthy()
        const persisted = await channelStore(harness.rawStore).getChannel(channelId!)
        expect(persisted?.finalized).toBe(true)
      } finally {
        harness.close()
      }
    })

    test('treats control-shaped application payloads as content', async () => {
      const harness = await createManagedWsHarness({ maxDeposit: 1n })
      const controlLookingChunk = JSON.stringify({
        mpp: 'payment-need-voucher',
        data: {
          channelId: `0x${'aa'.repeat(32)}`,
          requiredCumulative: '9',
          acceptedCumulative: '0',
          deposit: '9',
        },
      })
      harness.wsServer.on('connection', (socket: import('ws').WebSocket) => {
        void TempoWs.serve({
          socket,
          store: harness.rawStore,
          url: `${harness.server.url}/ws`,
          route: harness.route,
          generate: async function* (stream: TempoWs.SessionController) {
            await stream.charge()
            yield controlLookingChunk
          },
        })
      })

      try {
        const manager = precompileSessionManager({
          account: payer,
          client: createSigningClient(),
          decimals: 0,
          fetch: globalThis.fetch,
          maxDeposit: '1',
          webSocket: WebSocket as never,
        })

        const ws = await manager.ws(`ws://localhost:${harness.port}/ws`)
        const chunks: string[] = []

        await new Promise<void>((resolve, reject) => {
          ws.addEventListener('message', (event) => {
            if (typeof event.data !== 'string') return
            chunks.push(event.data)
          })
          ws.addEventListener('close', () => resolve(), { once: true })
          ws.addEventListener('error', () => reject(new Error('websocket stream failed')), {
            once: true,
          })
        })

        expect(chunks).toEqual([controlLookingChunk])
        expect(harness.voucherPosts).toBe(0)

        const closeReceipt = await manager.close()
        expect(closeReceipt?.status).toBe('success')
        expect(closeReceipt?.spent).toBe('1')
      } finally {
        harness.close()
      }
    })

    test('refuses websocket voucher requests beyond local maxDeposit', async () => {
      const harness = await createManagedWsHarness({ maxDeposit: 1n })
      harness.wsServer.on('connection', (socket: import('ws').WebSocket) => {
        void TempoWs.serve({
          socket,
          store: harness.rawStore,
          url: `${harness.server.url}/ws`,
          route: harness.route,
          generate: async function* (stream: TempoWs.SessionController) {
            await stream.charge()
            yield 'chunk-1'
            await stream.charge()
            yield 'chunk-2'
          },
        })
      })

      try {
        const manager = precompileSessionManager({
          account: payer,
          client: createSigningClient(),
          decimals: 0,
          fetch: globalThis.fetch,
          maxDeposit: '1',
          webSocket: WebSocket as never,
        })

        const ws = await manager.ws(`ws://localhost:${harness.port}/ws`)
        const closeEvent = await new Promise<{ code: number; reason: string }>(
          (resolve, reject) => {
            ws.addEventListener(
              'close',
              (event) => resolve({ code: event.code, reason: event.reason }),
              { once: true },
            )
            ws.addEventListener('error', () => reject(new Error('websocket stream failed')), {
              once: true,
            })
          },
        )

        expect(closeEvent.code).toBe(3008)
        expect(closeEvent.reason).toBe('requested voucher amount 2 exceeds local maxDeposit 1')
      } finally {
        harness.close()
      }
    })

    test('rejects websocket receipts bound to a different channel', async () => {
      const harness = await createManagedWsHarness({ maxDeposit: 1n })
      const wrongChannelId = `0x${'11'.repeat(32)}` as Hex
      harness.wsServer.on('connection', (socket: import('ws').WebSocket) => {
        socket.once('message', (data) => {
          const message = TempoWs.parseMessage(data.toString())
          if (!message || message.mpp !== 'authorization') return

          const credential = Credential.deserialize<SessionCredentialPayload>(message.authorization)
          socket.send(
            TempoWs.formatReceiptMessage({
              method: 'tempo',
              intent: 'session',
              status: 'success',
              timestamp: new Date().toISOString(),
              reference: wrongChannelId,
              challengeId: credential.challenge.id,
              channelId: wrongChannelId,
              acceptedCumulative: '1',
              spent: '0',
              units: 0,
            }),
          )
        })
      })

      try {
        const manager = precompileSessionManager({
          account: payer,
          client: createSigningClient(),
          decimals: 0,
          fetch: globalThis.fetch,
          maxDeposit: '1',
          webSocket: WebSocket as never,
        })

        await expect(manager.ws(`ws://localhost:${harness.port}/ws`)).rejects.toThrow(
          'received mismatched payment-receipt frame',
        )
      } finally {
        harness.close()
      }
    })

    test('rejects close-ready receipts beyond local voucher state', async () => {
      const harness = await createManagedWsHarness({ maxDeposit: 1n })
      harness.wsServer.on('connection', (socket: import('ws').WebSocket) => {
        let openCredential: Credential.Credential<SessionCredentialPayload> | undefined

        socket.on('message', (data) => {
          const message = TempoWs.parseMessage(data.toString())
          if (!message) return

          if (message.mpp === 'authorization') {
            openCredential = Credential.deserialize<SessionCredentialPayload>(message.authorization)
            const payload = openCredential.payload
            if (payload.action !== 'open') return
            socket.send(
              TempoWs.formatReceiptMessage({
                method: 'tempo',
                intent: 'session',
                status: 'success',
                timestamp: new Date().toISOString(),
                reference: payload.channelId,
                challengeId: openCredential.challenge.id,
                channelId: payload.channelId,
                acceptedCumulative: payload.cumulativeAmount,
                spent: '0',
                units: 0,
              }),
            )
            return
          }

          if (message.mpp !== 'payment-close-request' || !openCredential) return
          const payload = openCredential.payload
          socket.send(
            TempoWs.formatCloseReadyMessage({
              method: 'tempo',
              intent: 'session',
              status: 'success',
              timestamp: new Date().toISOString(),
              reference: payload.channelId,
              challengeId: openCredential.challenge.id,
              channelId: payload.channelId,
              acceptedCumulative: '1',
              spent: '9',
              units: 1,
            }),
          )
        })
      })

      try {
        const manager = precompileSessionManager({
          account: payer,
          client: createSigningClient(),
          decimals: 0,
          fetch: globalThis.fetch,
          maxDeposit: '1',
          webSocket: WebSocket as never,
        })

        await manager.ws(`ws://localhost:${harness.port}/ws`)
        await expect(manager.close()).rejects.toThrow(
          'received payment-close-ready beyond local voucher state',
        )
      } finally {
        harness.close()
      }
    })

    test('fallback close after socket death signs for delivered amount, not full voucher', async () => {
      const harness = await createManagedWsHarness({ maxDeposit: 3n })
      let serverSocket: import('ws').WebSocket | null = null
      harness.wsServer.on('connection', (socket: import('ws').WebSocket) => {
        serverSocket = socket
        void TempoWs.serve({
          socket,
          store: harness.rawStore,
          url: `${harness.server.url}/ws`,
          route: harness.route,
          generate: async function* (stream: TempoWs.SessionController) {
            await stream.charge()
            yield 'chunk-1'
            await stream.charge()
            yield 'chunk-2'
            await new Promise((resolve) => setTimeout(resolve, 60_000))
          },
        })
      })

      try {
        const manager = precompileSessionManager({
          account: payer,
          client: createSigningClient(),
          decimals: 0,
          fetch: globalThis.fetch,
          maxDeposit: '3',
          webSocket: WebSocket as never,
        })

        const ws = await manager.ws(`ws://localhost:${harness.port}/ws`)
        const chunks: string[] = []

        await new Promise<void>((resolve) => {
          ws.addEventListener('message', (event) => {
            if (typeof event.data !== 'string') return
            chunks.push(event.data)
            if (chunks.length === 2) serverSocket?.terminate()
          })
          ws.addEventListener('close', () => resolve(), { once: true })
        })

        expect(chunks).toEqual(['chunk-1', 'chunk-2'])

        const closeReceipt = await manager.close()
        expect(closeReceipt).toBeDefined()
        expect(BigInt(closeReceipt!.spent)).toBeLessThanOrEqual(2n)
        expect(BigInt(closeReceipt!.spent)).toBeGreaterThan(0n)
        expect(BigInt(closeReceipt!.spent)).toBeLessThan(3n)
      } finally {
        harness.close()
      }
    })

    test('rejects tx-bearing open receipts replayed during websocket close', async () => {
      const harness = await createManagedWsHarness({ maxDeposit: 1n })
      harness.wsServer.on('connection', (socket: import('ws').WebSocket) => {
        let openCredential: Credential.Credential<SessionCredentialPayload> | undefined
        let openReceipt: SessionReceipt | undefined

        socket.on('message', (data) => {
          const message = TempoWs.parseMessage(data.toString())
          if (!message) return

          if (message.mpp === 'authorization') {
            const credential = Credential.deserialize<SessionCredentialPayload>(
              message.authorization,
            )
            const payload = credential.payload
            if (payload.action === 'close') {
              if (openReceipt) socket.send(TempoWs.formatReceiptMessage(openReceipt))
              return
            }
            if (payload.action !== 'open') return

            openCredential = credential
            openReceipt = {
              method: 'tempo',
              intent: 'session',
              status: 'success',
              timestamp: new Date().toISOString(),
              reference: payload.channelId,
              challengeId: credential.challenge.id,
              channelId: payload.channelId,
              acceptedCumulative: payload.cumulativeAmount,
              spent: '0',
              units: 0,
              txHash: `0x${'12'.repeat(32)}` as Hex,
            }
            socket.send(TempoWs.formatReceiptMessage(openReceipt))
            return
          }

          if (message.mpp !== 'payment-close-request' || !openCredential) return
          const payload = openCredential.payload
          socket.send(
            TempoWs.formatCloseReadyMessage({
              method: 'tempo',
              intent: 'session',
              status: 'success',
              timestamp: new Date().toISOString(),
              reference: payload.channelId,
              challengeId: openCredential.challenge.id,
              channelId: payload.channelId,
              acceptedCumulative: '1',
              spent: '0',
              units: 0,
            }),
          )
        })
      })

      try {
        const manager = precompileSessionManager({
          account: payer,
          client: createSigningClient(),
          decimals: 0,
          fetch: globalThis.fetch,
          maxDeposit: '1',
          webSocket: WebSocket as never,
        })

        await manager.ws(`ws://localhost:${harness.port}/ws`)
        await expect(manager.close()).rejects.toThrow(
          'received mismatched payment-close receipt frame',
        )
      } finally {
        harness.close()
      }
    })
  })

  test('does not let a racing lower voucher regress highest accepted precompile voucher', async () => {
    const openPayload = await createOpenPayload({ initialAmount: 100n })
    const lowerVoucher = await ClientOps.createVoucherPayload(
      createSigningClient(),
      payer,
      openPayload.descriptor,
      Types.uint96(200n),
      chainId,
    )
    const higherVoucher = await ClientOps.createVoucherPayload(
      createSigningClient(),
      payer,
      openPayload.descriptor,
      Types.uint96(500n),
      chainId,
    )
    if (higherVoucher.action !== 'voucher') throw new Error('expected voucher payload')

    const seedStore = channelStore(Store.memory())
    await persistPrecompileChannel(seedStore, openPayload, {
      highestVoucherAmount: 100n,
      highestVoucher: {
        channelId: openPayload.channelId,
        cumulativeAmount: 100n,
        signature: openPayload.signature,
      },
    })
    const stale = (await seedStore.getChannel(openPayload.channelId))!
    let stored: ChannelStore.State = {
      ...stale,
      highestVoucherAmount: 500n,
      highestVoucher: {
        channelId: openPayload.channelId,
        cumulativeAmount: 500n,
        signature: higherVoucher.signature,
      },
    }
    const racingStore = {
      async get(_key: string) {
        return stale as never
      },
      async put(_key: string, value: unknown) {
        stored = value as ChannelStore.State
      },
      async delete(_key: string) {},
      async update<result>(
        _key: string,
        fn: (current: unknown | null) => Store.Change<unknown, result>,
      ): Promise<result> {
        const change = fn(stored)
        if (change.op === 'set') stored = change.value as ChannelStore.State
        return change.result
      },
    } as Store.AtomicStore
    const method = session({
      account: payer,
      amount: '1',
      chainId,
      channelStateTtl: Number.MAX_SAFE_INTEGER,
      currency: token,
      decimals: 0,
      recipient: payee,
      store: racingStore,
      unitType: 'request',
      getClient: () => createStateClient(payer),
    })

    const receipt = await method.verify({
      credential: {
        challenge: makeChallenge(openPayload.channelId),
        payload: lowerVoucher,
      },
      request: verifyRequest(openPayload.channelId),
    })

    expect((receipt as SessionReceipt).acceptedCumulative).toBe('500')
    expect(stored.highestVoucherAmount).toBe(500n)
    expect(stored.highestVoucher?.signature).toBe(higherVoucher.signature)
  })

  test('marks pending precompile close before broadcast and restores it when broadcast fails', async () => {
    const rawStore = Store.memory()
    const store = channelStore(rawStore)
    const openPayload = await createOpenPayload()
    await persistPrecompileChannel(store, openPayload, {
      payee: payer.address,
    })
    let observedPending = false
    const method = session({
      account: payer,
      amount: '1',
      chainId,
      currency: token,
      decimals: 0,
      recipient: payee,
      store: rawStore,
      unitType: 'request',
      getClient: () =>
        createClient({
          account: payer,
          chain: testChain,
          transport: custom({
            async request(args) {
              if (args.method === 'eth_chainId') return `0x${chainId.toString(16)}`
              if (args.method === 'eth_call')
                return encodeFunctionResult({
                  abi: escrowAbi,
                  functionName: 'getChannelState',
                  result: { settled: 0n, deposit: 1_000n, closeRequestedAt: 0 },
                })
              if (args.method === 'eth_getTransactionCount') {
                observedPending =
                  (await store.getChannel(openPayload.channelId))!.closeRequestedAt !== 0n
                throw new Error('broadcast failed')
              }
              if (args.method === 'eth_estimateGas') return '0x5208'
              if (args.method === 'eth_maxPriorityFeePerGas') return '0x1'
              if (args.method === 'eth_getBlockByNumber') return { baseFeePerGas: '0x1' }
              throw new Error(`unexpected rpc request: ${args.method}`)
            },
          }),
        }),
    })
    const payload = await ClientOps.createClosePayload(
      createSigningClient(),
      payer,
      openPayload.descriptor,
      Types.uint96(100n),
      chainId,
    )

    await expect(
      method.verify({
        credential: {
          challenge: makeChallenge(openPayload.channelId),
          payload,
        },
        request: verifyRequest(openPayload.channelId),
      }),
    ).rejects.toThrow(/broadcast failed/)
    expect(observedPending).toBe(true)
    expect((await store.getChannel(openPayload.channelId))!.closeRequestedAt).toBe(0n)
  })

  test('precompile settle returns txHash when channel disappears before final write', async () => {
    const rawStore = Store.memory()
    const store = channelStore(rawStore)
    const openPayload = await createOpenPayload({ initialAmount: 100n })
    await persistPrecompileChannel(store, openPayload, { payee: payer.address })
    const client = createServerClient([], payer, openPayload.channelId, {
      receipt: transactionReceipt([settledLog(openPayload.channelId, 100n)]),
      state: { settled: 100n, deposit: 1_000n, closeRequestedAt: 0 },
    })
    let deleted = false
    const disappearingStore = {
      async get(key: string) {
        return rawStore.get(key)
      },
      async put(key: string, value: unknown) {
        return rawStore.put(key, value)
      },
      async delete(key: string) {
        return rawStore.delete(key)
      },
      async update<result>(
        key: string,
        fn: (current: unknown | null) => Store.Change<unknown, result>,
      ): Promise<result> {
        if (!deleted) {
          deleted = true
          return rawStore.update(key, fn)
        }
        const change = fn(null)
        return change.result
      },
    } as Store.AtomicStore

    const { settle } = await import('./Session.js')
    await expect(settle(disappearingStore, client, openPayload.channelId)).resolves.toBe(
      `0x${'aa'.repeat(32)}`,
    )
  })

  test('precompile close still returns receipt when channel disappears before final write', async () => {
    const rawStore = Store.memory()
    const store = channelStore(rawStore)
    const openPayload = await createOpenPayload({ initialAmount: 100n })
    await persistPrecompileChannel(store, openPayload, { payee: payer.address, spent: 100n })
    const closeSignature = await Voucher.signVoucher(
      createSigningClient(),
      payer,
      { channelId: openPayload.channelId, cumulativeAmount: 100n },
      tip20ChannelEscrow,
      chainId,
    )
    const method = session({
      account: payer,
      amount: '1',
      chainId,
      currency: token,
      decimals: 0,
      recipient: payee,
      store: rawStore,
      unitType: 'request',
      getClient: () =>
        createServerClient([], payer, openPayload.channelId, {
          receipt: transactionReceipt([closedLog(openPayload.channelId, 100n, 900n)]),
          state: { settled: 0n, deposit: 1_000n, closeRequestedAt: 0 },
        }),
    })
    let deleteBeforeFinalWrite = false
    const originalUpdate = store.updateChannel.bind(store)
    store.updateChannel = (async (channelId, fn) => {
      if (deleteBeforeFinalWrite) return fn(null as never) as never
      const result = await originalUpdate(channelId, fn)
      deleteBeforeFinalWrite = true
      return result
    }) as typeof store.updateChannel

    const receipt = (await method.verify({
      credential: {
        challenge: makeChallenge(openPayload.channelId),
        payload: {
          action: 'close',
          channelId: openPayload.channelId,
          cumulativeAmount: '100',
          descriptor: openPayload.descriptor,
          signature: closeSignature,
        },
      },
      request: verifyRequest(openPayload.channelId),
    })) as SessionReceipt

    expect(receipt.txHash).toBe(`0x${'aa'.repeat(32)}`)
    expect(receipt.spent).toBe('100')
  })

  test('rejects close when precompile channel is finalized on-chain', async () => {
    const rawStore = Store.memory()
    const store = channelStore(rawStore)
    const openPayload = await createOpenPayload({ initialAmount: 100n })
    await persistPrecompileChannel(store, openPayload, { payee: payer.address, spent: 100n })
    const closeSignature = await Voucher.signVoucher(
      createSigningClient(),
      payer,
      { channelId: openPayload.channelId, cumulativeAmount: 100n },
      tip20ChannelEscrow,
      chainId,
    )
    const method = session({
      account: payer,
      amount: '1',
      chainId,
      currency: token,
      decimals: 0,
      recipient: payee,
      store: rawStore,
      unitType: 'request',
      getClient: () => createStateClient(payer, { settled: 0n, deposit: 0n, closeRequestedAt: 0 }),
    })

    await expect(
      method.verify({
        credential: {
          challenge: makeChallenge(openPayload.channelId),
          payload: {
            action: 'close',
            channelId: openPayload.channelId,
            cumulativeAmount: '100',
            descriptor: openPayload.descriptor,
            signature: closeSignature,
          },
        },
        request: verifyRequest(openPayload.channelId),
      }),
    ).rejects.toThrow(/channel deposit is zero/)
  })

  test('pending precompile close blocks concurrent charges', async () => {
    const { store } = createServer()
    const openPayload = await createOpenPayload({ initialAmount: 100n })
    await persistPrecompileChannel(store, openPayload, {
      closeRequestedAt: 1n,
      highestVoucherAmount: 500n,
      spent: 100n,
    })

    await expect(charge(store, openPayload.channelId, 1n)).rejects.toThrow(/pending close request/)
  })

  test('rejects server-driven close when no account is available', async () => {
    const rawStore = Store.memory()
    const store = channelStore(rawStore)
    const openPayload = await createOpenPayload()
    await persistPrecompileChannel(store, openPayload)
    const method = session({
      amount: '1',
      chainId,
      currency: token,
      decimals: 0,
      recipient: payee,
      store: rawStore,
      unitType: 'request',
      getClient: () => createStateClient(null),
    })
    const payload = await ClientOps.createClosePayload(
      createSigningClient(),
      payer,
      openPayload.descriptor,
      Types.uint96(100n),
      chainId,
    )

    await expect(
      method.verify({
        credential: {
          challenge: makeChallenge(openPayload.channelId),
          payload,
        },
        request: verifyRequest(openPayload.channelId),
      }),
    ).rejects.toThrow(/no account available/)
  })

  test('accepts server-driven close account override matching the channel payee', async () => {
    const rawStore = Store.memory()
    const store = channelStore(rawStore)
    const openPayload = await createOpenPayload()
    await persistPrecompileChannel(store, openPayload, {
      payee: wrongPayer.address,
    })
    const method = session({
      account: wrongPayer,
      amount: '1',
      chainId,
      currency: token,
      decimals: 0,
      recipient: payee,
      store: rawStore,
      unitType: 'request',
      getClient: () => createStateClient(payer),
    })
    const payload = await ClientOps.createClosePayload(
      createSigningClient(),
      payer,
      openPayload.descriptor,
      Types.uint96(100n),
      chainId,
    )

    await expect(
      method.verify({
        credential: {
          challenge: makeChallenge(openPayload.channelId),
          payload,
        },
        request: verifyRequest(openPayload.channelId),
      }),
    ).rejects.toThrow(/eth_sendRawTransaction/)
  })

  test('uses request-specified fee payer account for server-driven precompile close', async () => {
    const rawStore = Store.memory()
    const store = channelStore(rawStore)
    const openPayload = await createOpenPayload()
    await persistPrecompileChannel(store, openPayload, {
      payee: wrongPayer.address,
    })
    const method = session({
      account: wrongPayer,
      amount: '1',
      chainId,
      currency: token,
      decimals: 0,
      feeToken: token,
      recipient: payee,
      store: rawStore,
      unitType: 'request',
      getClient: () => createStateClient(payer),
    })
    const payload = await ClientOps.createClosePayload(
      createSigningClient(),
      payer,
      openPayload.descriptor,
      Types.uint96(100n),
      chainId,
    )

    await expect(
      method.verify({
        credential: {
          challenge: makeChallenge(openPayload.channelId),
          payload,
        },
        request: verifyRequestWithFeePayer(openPayload.channelId, payer),
      }),
    ).rejects.toThrow(/eth_sendRawTransaction/)
  })

  test('accepts server-driven close sender matching a nonzero precompile operator', async () => {
    const rawStore = Store.memory()
    const store = channelStore(rawStore)
    const openPayload = await createOpenPayload({
      operator: wrongPayer.address,
    })
    await persistPrecompileChannel(store, openPayload)
    const method = session({
      account: wrongPayer,
      amount: '1',
      chainId,
      currency: token,
      decimals: 0,
      recipient: payee,
      operator: wrongPayer.address,
      store: rawStore,
      unitType: 'request',
      getClient: () => createStateClient(payer),
    })
    const payload = await ClientOps.createClosePayload(
      createSigningClient(),
      payer,
      openPayload.descriptor,
      Types.uint96(100n),
      chainId,
    )

    await expect(
      method.verify({
        credential: {
          challenge: makeChallenge(openPayload.channelId, { operator: wrongPayer.address }),
          payload,
        },
        request: verifyRequest(openPayload.channelId, { operator: wrongPayer.address }),
      }),
    ).rejects.toThrow(/eth_sendRawTransaction/)
  })

  test('rejects server-driven close when sender is not the channel payee or operator', async () => {
    const rawStore = Store.memory()
    const store = channelStore(rawStore)
    const openPayload = await createOpenPayload()
    await persistPrecompileChannel(store, openPayload)
    const method = session({
      amount: '1',
      chainId,
      currency: token,
      decimals: 0,
      recipient: payee,
      store: rawStore,
      unitType: 'request',
      getClient: () => createStateClient(wrongPayer),
    })
    const payload = await ClientOps.createClosePayload(
      createSigningClient(),
      payer,
      openPayload.descriptor,
      Types.uint96(100n),
      chainId,
    )

    await expect(
      method.verify({
        credential: {
          challenge: makeChallenge(openPayload.channelId),
          payload,
        },
        request: verifyRequest(openPayload.channelId),
      }),
    ).rejects.toThrow(/tx sender .* is not the channel payee/)
  })
})

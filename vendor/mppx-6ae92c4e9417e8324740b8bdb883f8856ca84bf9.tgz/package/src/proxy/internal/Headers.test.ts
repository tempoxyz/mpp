import { describe, expect, test } from 'vp/test'

import * as Headers from './Headers.js'

describe('scrub', () => {
  test('behavior: strips authorization header', () => {
    const headers = new globalThis.Headers({
      Authorization: 'Bearer secret',
      'Content-Type': 'application/json',
    })
    const result = Headers.scrub(headers)
    expect(result.has('authorization')).toBe(false)
    expect(result.get('content-type')).toBe('application/json')
  })

  test('behavior: strips payment protocol headers', () => {
    const headers = new globalThis.Headers({
      'Accept-Payment': 'evm/charge',
      'Content-Type': 'application/json',
      'PAYMENT-RECEIPT': 'receipt',
      'PAYMENT-REQUIRED': 'required',
      'PAYMENT-RESPONSE': 'response',
      'PAYMENT-SIGNATURE': 'signature',
      'WWW-Authenticate': 'Payment id="abc"',
    })
    const result = Headers.scrub(headers)
    expect(result.has('accept-payment')).toBe(false)
    expect(result.has('payment-receipt')).toBe(false)
    expect(result.has('payment-required')).toBe(false)
    expect(result.has('payment-response')).toBe(false)
    expect(result.has('payment-signature')).toBe(false)
    expect(result.has('www-authenticate')).toBe(false)
    expect(result.get('content-type')).toBe('application/json')
  })

  test('behavior: strips cookie header', () => {
    const headers = new globalThis.Headers({
      Cookie: 'session=abc123',
      Accept: 'text/html',
    })
    const result = Headers.scrub(headers)
    expect(result.has('cookie')).toBe(false)
    expect(result.get('accept')).toBe('text/html')
  })

  test('behavior: strips hop-by-hop headers', () => {
    const headers = new globalThis.Headers({
      Connection: 'keep-alive',
      'Keep-Alive': 'timeout=5',
      'Transfer-Encoding': 'chunked',
      Upgrade: 'websocket',
      'Proxy-Authenticate': 'Basic',
      'Proxy-Authorization': 'Basic abc',
      TE: 'trailers',
      Trailer: 'Expires',
      'Content-Type': 'application/json',
    })
    const result = Headers.scrub(headers)
    expect(result.has('connection')).toBe(false)
    expect(result.has('keep-alive')).toBe(false)
    expect(result.has('transfer-encoding')).toBe(false)
    expect(result.has('upgrade')).toBe(false)
    expect(result.has('proxy-authenticate')).toBe(false)
    expect(result.has('proxy-authorization')).toBe(false)
    expect(result.has('te')).toBe(false)
    expect(result.has('trailer')).toBe(false)
    expect(result.get('content-type')).toBe('application/json')
  })

  test('behavior: strips x-forwarded-* headers', () => {
    const headers = new globalThis.Headers({
      'X-Forwarded-For': '127.0.0.1',
      'X-Forwarded-Proto': 'https',
      'X-Forwarded-Host': 'example.com',
      Accept: '*/*',
    })
    const result = Headers.scrub(headers)
    expect(result.has('x-forwarded-for')).toBe(false)
    expect(result.has('x-forwarded-proto')).toBe(false)
    expect(result.has('x-forwarded-host')).toBe(false)
    expect(result.get('accept')).toBe('*/*')
  })

  test('behavior: preserves safe headers', () => {
    const headers = new globalThis.Headers({
      'Content-Type': 'application/json',
      Accept: 'text/html',
      'User-Agent': 'test-agent/1.0',
      'X-Custom-Header': 'value',
    })
    const result = Headers.scrub(headers)
    expect(result.get('content-type')).toBe('application/json')
    expect(result.get('accept')).toBe('text/html')
    expect(result.get('user-agent')).toBe('test-agent/1.0')
    expect(result.get('x-custom-header')).toBe('value')
  })
})

describe('scrubResponse', () => {
  test('behavior: strips content-encoding and content-length', () => {
    const response = new Response('body', {
      headers: {
        'Content-Encoding': 'gzip',
        'Content-Length': '42',
        'Content-Type': 'application/json',
      },
    })
    const result = Headers.scrubResponse(response)
    expect(result.headers.has('content-encoding')).toBe(false)
    expect(result.headers.has('content-length')).toBe(false)
    expect(result.headers.get('content-type')).toBe('application/json')
  })

  test('behavior: preserves status and body', async () => {
    const response = new Response('hello', { status: 201, statusText: 'Created' })
    const result = Headers.scrubResponse(response)
    expect(result.status).toBe(201)
    expect(result.statusText).toBe('Created')
    expect(await result.text()).toBe('hello')
  })

  // Regression: an upstream service must never be able to issue a cookie
  // under the proxy's origin. Otherwise a compromised or attacker-influenced
  // upstream can session-fixate (`Set-Cookie: session=evil; Domain=…`) every
  // sibling subdomain of the proxy. See the docblock on `scrubResponse`.
  test('behavior: strips set-cookie so upstream cannot set cookies on proxy origin', () => {
    const response = new Response('body', {
      headers: [
        ['Set-Cookie', '__Secure-session=evil; Domain=.example.com; Secure; HttpOnly'],
        ['Set-Cookie', 'tracking=1; Path=/'],
        ['Content-Type', 'application/json'],
      ],
    })
    const result = Headers.scrubResponse(response)
    expect(result.headers.has('set-cookie')).toBe(false)
    expect(result.headers.getSetCookie?.() ?? []).toEqual([])
    expect(result.headers.get('content-type')).toBe('application/json')
  })
})
